/**
 * Business Owner Platform — About Us Page
 * Design: Institutional Authority (matches Home page)
 * Colors: Value Green #1A3D2E | Gold #B8922E | Cream #F0EBE0
 * Fonts: Oswald (headlines) | Barlow (subheads/body)
 */

import { useEffect, useRef } from "react";

const BOP_LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/AAhEwqRgJGZhnRtZwJrWVS/bop_logo_baa7a023.png";
const NVG_LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/AAhEwqRgJGZhnRtZwJrWVS/nvg_logo_7a591d90.png";
const RAY_PHOTO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/XEGS9UnebTmPzBQyvB3V8k/ray_croff_real_photo_d00829ef.png";
const PATRICK_PHOTO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/XEGS9UnebTmPzBQyvB3V8k/patrick_smith_photo_d064623f.jpg";
const GER_LOGO = "/manus-storage/growth_exit_roundtable_logo_8b6c2ceb.png";

function useFadeUp() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { el.classList.add("visible"); obs.disconnect(); } },
      { threshold: 0.08 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return ref;
}

// ─── Nav (shared with Home) ───────────────────────────────────────────────────
function Nav() {
  return (
    <nav
      role="navigation"
      aria-label="Main navigation"
      className="fixed top-0 left-0 right-0 z-50"
      style={{
        backgroundColor: "oklch(0.24 0.07 155)",
        borderBottom: "1px solid oklch(1 0 0 / 0.08)",
      }}
    >
      <div className="container flex items-center justify-between" style={{ height: "68px" }}>
        <a href="/" aria-label="Business Owner Platform — Home" className="flex-shrink-0">
          <img src={BOP_LOGO} alt="Business Owner Platform" style={{ height: "44px", width: "auto" }} />
        </a>
        <div className="hidden lg:flex items-center gap-6">
          {[["Home", "/"], ["The Roundtable", "/roundtable"], ["Free Snapshot", "/snapshot"], ["Platform", "/#platform"], ["About Us", "/about"]].map(([label, href]) => (
            <a
              key={href}
              href={href}
              className="font-subhead hover:text-gold transition-colors duration-200"
              style={{ fontSize: "0.72rem", letterSpacing: "0.1em", color: label === "About Us" ? "oklch(0.65 0.10 75)" : "oklch(0.94 0.015 80)" }}
            >
              {label}
            </a>
          ))}
        </div>
        <div className="hidden lg:flex items-center gap-2">
          <a href="/snapshot" className="btn-outline" style={{ padding: "0.6rem 1.25rem", fontSize: "0.72rem" }}>
            Free Business Assessment
          </a>
          <a href="/roundtable" className="btn-primary" style={{ padding: "0.6rem 1.25rem", fontSize: "0.72rem" }}>
            Attend the Roundtable
          </a>
        </div>
      </div>
    </nav>
  );
}

// ─── Page Hero ────────────────────────────────────────────────────────────────
function PageHero() {
  return (
    <section
      aria-label="About Us hero"
      style={{
        background: "linear-gradient(135deg, oklch(0.20 0.08 155) 0%, oklch(0.28 0.07 155) 100%)",
        paddingTop: "68px",
      }}
    >
      <div className="container py-20">
        <p className="section-label text-gold mb-4">Our Leadership</p>
        <span className="gold-rule" />
        <h1 className="font-headline text-cream mb-6" style={{ fontSize: "clamp(2.2rem, 4.5vw, 3.5rem)", maxWidth: "700px", lineHeight: 1.1 }}>
          The People Behind the Platform
        </h1>
        <p className="text-cream/80 max-w-2xl" style={{ fontSize: "1.05rem", lineHeight: 1.75 }}>
          The Business Owner Platform was built by people who have been on both sides of the table — as business owners, as advisors, and as the people who had to figure it out the hard way. What we teach, we have lived.
        </p>
      </div>
    </section>
  );
}

// ─── Founding Story ───────────────────────────────────────────────────────────
function FoundingStory() {
  const ref = useFadeUp();
  return (
    <section aria-labelledby="founding-heading" className="bg-cream py-20">
      <div className="container">
        <div ref={ref} className="fade-up max-w-3xl">
          <p className="section-label text-value-green mb-3">Our Story</p>
          <span className="gold-rule" />
          <h2 id="founding-heading" className="font-headline text-value-green mb-6" style={{ fontSize: "clamp(1.6rem, 3vw, 2.2rem)" }}>
            Built From Experience. Driven by a Gap No One Was Filling.
          </h2>
          <p className="mb-5" style={{ color: "oklch(0.35 0.02 65)", lineHeight: 1.8 }}>
            The Business Owner Platform exists because two people — one a former business owner turned exit planning advisor, the other a growth architect with 40 years of real-world scaling experience — looked at the landscape of business advisory services and saw the same thing: owners were being served last.
          </p>
          <p style={{ color: "oklch(0.35 0.02 65)", lineHeight: 1.8 }}>
            Most advisory relationships begin when a business owner is already in crisis mode — ready to sell, facing a health event, or running out of runway. The Business Owner Platform was built to change that. We reach owners early, educate them honestly, and give them the tools to build a business that works for them — whether they ever sell it or not.
          </p>
        </div>
      </div>
    </section>
  );
}

// ─── Leader Profile ───────────────────────────────────────────────────────────
interface LeaderProps {
  name: string;
  title: string;
  subtitle?: string;
  photo: string;
  photoAlt: string;
  credentials: string[];
  bios: string[];
  flip?: boolean;
  bg?: string;
}

function LeaderProfile({ name, title, subtitle, photo, photoAlt, credentials, bios, flip = false, bg = "oklch(0.88 0.02 80)" }: LeaderProps) {
  const ref = useFadeUp();
  return (
    <section aria-labelledby={`leader-${name.replace(/\s/g, "-").toLowerCase()}`} style={{ background: bg }} className="py-20">
      <div className="container">
        <div
          ref={ref}
          className="fade-up grid lg:grid-cols-2 gap-12 lg:gap-16 items-start"
          style={{ direction: flip ? "rtl" : "ltr" }}
        >
          {/* Photo column */}
          <div style={{ direction: "ltr", position: "relative" }}>
            {/* Photo */}
            <div style={{ position: "relative", overflow: "hidden" }}>
              <img
                src={photo}
                alt={photoAlt}
                loading="lazy"
                style={{
                  width: "100%",
                  maxWidth: "480px",
                  aspectRatio: "4/5",
                  objectFit: "cover",
                  objectPosition: "top center",
                  display: "block",
                }}
              />
              {/* Gold corner accent */}
              <div style={{
                position: "absolute",
                bottom: 0,
                left: 0,
                right: 0,
                background: "linear-gradient(to top, oklch(0.24 0.07 155 / 0.85) 0%, transparent 60%)",
                padding: "2rem 1.5rem 1.5rem",
              }}>
                <span className="font-headline text-cream block" style={{ fontSize: "1.3rem" }}>{name}</span>
                <span className="text-gold block" style={{ fontSize: "0.8rem", letterSpacing: "0.05em" }}>{title}</span>
              </div>
            </div>

            {/* Credential badges */}
            <div style={{
              background: "oklch(0.24 0.07 155)",
              padding: "1.5rem",
              maxWidth: "480px",
            }}>
              <p className="section-label text-gold mb-3">Credentials</p>
              <ul className="space-y-2 list-none p-0 m-0">
                {credentials.map((c) => (
                  <li key={c} className="flex gap-2 items-start" style={{ color: "oklch(0.94 0.015 80)", fontSize: "0.85rem", lineHeight: 1.5 }}>
                    <span className="text-gold flex-shrink-0 mt-0.5">✦</span>
                    {c}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Bio column */}
          <div style={{ direction: "ltr" }}>
            <p className="section-label text-value-green mb-3">{subtitle || title}</p>
            <span className="gold-rule" />
            <h2
              id={`leader-${name.replace(/\s/g, "-").toLowerCase()}`}
              className="font-headline text-value-green mb-2"
              style={{ fontSize: "clamp(1.8rem, 3vw, 2.5rem)" }}
            >
              {name}
            </h2>
            <p className="text-gold font-semibold mb-8" style={{ fontSize: "0.9rem", letterSpacing: "0.04em" }}>{title}</p>
            <div className="space-y-5">
              {bios.map((para, i) => (
                <p key={i} style={{ color: "oklch(0.35 0.02 65)", lineHeight: 1.8, fontSize: "0.975rem" }}>
                  {para}
                </p>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── CTA Banner ───────────────────────────────────────────────────────────────
function CTABanner() {
  const ref = useFadeUp();
  return (
    <section aria-label="Call to action" style={{ background: "oklch(0.65 0.10 75)" }} className="py-20">
      <div className="container">
        <div ref={ref} className="fade-up text-center max-w-2xl mx-auto">
          <div className="flex justify-center mb-8">
            <img
              src={GER_LOGO}
              alt="Growth and Exit Roundtable — Presented by NorthStar Value Group"
              style={{ width: "260px", height: "auto" }}
            />
          </div>
          <h2 className="font-headline mb-5" style={{ color: "oklch(0.18 0.02 65)", fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", lineHeight: 1.15 }}>
            Ready to Hear the Truth About Your Business?
          </h2>
          <p className="mb-8" style={{ color: "oklch(0.25 0.02 65)", fontSize: "1rem", lineHeight: 1.75 }}>
            The first step is a Growth and Exit Roundtable — free, honest, and built for business owners who are ready to act.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/roundtable" className="btn-outline-dark">Attend the Roundtable</a>
            <a href="/" className="btn-outline-dark">Explore the Platform</a>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer role="contentinfo" style={{ background: "oklch(0.16 0.06 155)", borderTop: "1px solid oklch(1 0 0 / 0.08)" }}>
      <div className="container py-16">
        <div className="grid md:grid-cols-4 gap-10 mb-12">
          <div className="md:col-span-1">
            <img src={BOP_LOGO} alt="Business Owner Platform" style={{ height: "48px", width: "auto", marginBottom: "1rem" }} />
            <p className="text-cream/60" style={{ fontSize: "0.85rem", lineHeight: 1.7 }}>
              A platform of Northstar Value Group. Helping business owners build more valuable, less owner-dependent businesses.
            </p>
          </div>
          <div>
            <h5 className="font-subhead text-gold mb-4">Platform</h5>
            <ul className="space-y-2 list-none p-0 m-0">
              {[["The Problem", "/#problem"], ["Our Approach", "/#approach"], ["Growth and Exit Roundtable", "/roundtable"], ["Exit Readiness Snapshot", "/snapshot"], ["Who We Serve", "/#who"]].map(([label, href]) => (
                <li key={href}><a href={href} className="text-cream/60 hover:text-gold transition-colors" style={{ fontSize: "0.85rem" }}>{label}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="font-subhead text-gold mb-4">About</h5>
            <ul className="space-y-2 list-none p-0 m-0">
              {[["About Us", "/about"], ["Ray Croff", "/about#ray-croff"], ["Patrick K. Smith", "/about#patrick-k.-smith"], ["FAQ", "/#faq"]].map(([label, href]) => (
                <li key={label}><a href={href} className="text-cream/60 hover:text-gold transition-colors" style={{ fontSize: "0.85rem" }}>{label}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="font-subhead text-gold mb-4">Connect</h5>
            <ul className="space-y-2 list-none p-0 m-0">
              {[["Register for a Roundtable", "/#roundtable"], ["Contact Us", "/#cta"], ["Advisor Network", "/#roundtable"]].map(([label, href]) => (
                <li key={label}><a href={href} className="text-cream/60 hover:text-gold transition-colors" style={{ fontSize: "0.85rem" }}>{label}</a></li>
              ))}
            </ul>
          </div>
        </div>
        <div style={{ borderTop: "1px solid oklch(1 0 0 / 0.08)", paddingTop: "2rem" }} className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-3">
            <img src={NVG_LOGO} alt="Northstar Value Group" style={{ height: "28px", width: "auto", opacity: 0.7 }} />
            <span className="text-cream/40" style={{ fontSize: "0.8rem" }}>A Northstar Value Group Platform</span>
          </div>
          <div className="flex gap-6">
            <a href="#" className="text-cream/40 hover:text-cream/70 transition-colors" style={{ fontSize: "0.8rem" }}>Privacy Policy</a>
            <a href="#" className="text-cream/40 hover:text-cream/70 transition-colors" style={{ fontSize: "0.8rem" }}>Terms of Use</a>
            <span className="text-cream/30" style={{ fontSize: "0.8rem" }}>© {year} Northstar Value Group</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─── Schema markup ────────────────────────────────────────────────────────────
function SchemaMarkup() {
  const schema = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "AboutPage",
        "name": "About Us — Business Owner Platform Leadership",
        "description": "Meet the leadership team behind the Business Owner Platform: Ray Croff, Founder & CEO of Northstar Value Group, and Patrick K. Smith, Chief Marketing Officer.",
        "url": "https://businessownerplatform.com/about",
      },
      {
        "@type": "Person",
        "name": "Ray Croff",
        "jobTitle": "Founder & CEO, Northstar Value Group",
        "image": RAY_PHOTO,
        "description": "Certified Exit Planning Advisor (CEPA) and Certified Value Growth Advisor (CVGA) with over 15 years of experience working with business owners on value building, succession planning, and exit strategy.",
        "hasCredential": ["CEPA — Certified Exit Planning Advisor", "CVGA — Certified Value Growth Advisor"],
        "worksFor": { "@type": "Organization", "name": "Northstar Value Group" },
      },
      {
        "@type": "Person",
        "name": "Patrick K. Smith",
        "jobTitle": "Chief Marketing Officer, Northstar Value Group",
        "image": PATRICK_PHOTO,
        "description": "Growth Architect and CMO with over 40 years of real-world business scaling experience. Pioneer of Relationship Marketing principles and AI-powered business automation.",
        "worksFor": { "@type": "Organization", "name": "Northstar Value Group" },
      },
    ],
  };
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />;
}

// ─── Main export ──────────────────────────────────────────────────────────────
export default function About() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <SchemaMarkup />
      <Nav />
      <main id="main" style={{ paddingTop: 0 }}>
        <PageHero />
        <FoundingStory />

        <LeaderProfile
          name="Ray Croff"
          title="Founder & CEO, Northstar Value Group"
          subtitle="Founder & CEO"
          photo={RAY_PHOTO}
          photoAlt="Ray Croff, Founder and CEO of Northstar Value Group"
          credentials={[
            "CEPA — Certified Exit Planning Advisor",
            "CVGA — Certified Value Growth Advisor",
            "Dallas EPI Chapter President",
            "Named One of the Best CEPAs in the U.S. (2020)",
          ]}
          bios={[
            "Ray Croff is the founder of the Trusted Advisor Collaborative and CEO of Northstar Value Group. He is a Certified Exit Planning Advisor (CEPA) and Certified Value Growth Advisor (CVGA) with over 15 years of experience working directly with business owners on value building, succession planning, and exit strategy.",
            "Ray's perspective is shaped by something most advisors lack: he has been on the other side of the table. As a former business owner who ran a company with employees, equipment, and real estate, he understands the complexity, the emotional weight, and the financial stakes of transitioning a business — not just as a concept, but as a lived experience.",
            "That firsthand knowledge led Ray to develop the Owner's Roundtable — a structured educational process for helping business owners understand and increase the value of their companies. From that foundation, he created the Growth and Exit Roundtable program, a 6-module roundtable series that has helped business owners across the country prepare for growth, transition, and exit.",
            "In 2020, Ray was named one of the best CEPAs in the United States and served as Dallas Chapter President of the Exit Planning Institute. He previously built and led the Advisors Edge platform, which connected advisors with business owner clients through education-first roundtables. The Trusted Advisor Collaborative is the next evolution of that work — a fully modernized, team-based platform built under Northstar Value Group.",
          ]}
          flip={false}
          bg="oklch(0.88 0.02 80)"
        />

        <LeaderProfile
          name="Patrick K. Smith"
          title="Chief Marketing Officer — Northstar Value Group"
          subtitle="Growth Architect & CMO"
          photo={PATRICK_PHOTO}
          photoAlt="Patrick K. Smith, Chief Marketing Officer of Northstar Value Group"
          credentials={[
            "Growth Architecture & Systems Design",
            "Relationship Marketing (since the 1990s)",
            "AI-Powered Business Automation",
            "40+ Years of Real-World Business Scaling",
          ]}
          bios={[
            "Patrick K. Smith is the Chief Marketing Officer for Northstar Value Group, the Trusted Advisor Collaborative, and the Business Owner Platform. As a Growth Architect and CMO, he brings over 40 years of real-world business scaling experience — from managing 100-door truck docks to building multi-state real estate firms averaging millions in annual sales.",
            "Patrick's philosophy is simple: a business should serve its owner, not the other way around. He pioneered \"Relationship Marketing\" principles in the 1990s — principles that remain the foundation of how the TAC builds trust with business owners today. He combines those time-tested frameworks with the most advanced AI-powered growth tools available, helping advisors and business owners organize their models, automate the busy work, and build companies that run independently of their daily presence.",
            "In 2013, a serious automobile accident forced Patrick to step back from his businesses. His recovery attorney recognized the power of the marketing and growth systems Patrick had built — and asked if he could replicate them for other clients. That moment became the spark for his current work: helping business owners build systems that scale without them, and creating assets valuable enough to sell.",
            "At the TAC, Patrick architects the marketing infrastructure that gives every platform a consistent, professional presence — from automated follow-up systems and content libraries to AI-powered outreach tools and the brand identity that positions the team as a trusted authority in their market.",
          ]}
          flip={true}
          bg="oklch(0.94 0.015 80)"
        />

        <CTABanner />
      </main>
      <Footer />
    </>
  );
}
