/**
 * Business Owner Platform — Home Page
 * Design: Institutional Authority
 * Colors: Value Green #1A3D2E | Gold #B8922E | Cream #F0EBE0
 * Fonts: Oswald (headlines) | Barlow (subheads/body)
 */

import { useEffect, useRef, useState } from "react";

const BOP_LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/AAhEwqRgJGZhnRtZwJrWVS/bop_logo_baa7a023.png";
const NVG_LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/AAhEwqRgJGZhnRtZwJrWVS/nvg_logo_7a591d90.png";
const GER_LOGO = "/manus-storage/growth_exit_roundtable_logo_8b6c2ceb.png";

// ─── Scroll animation hook ────────────────────────────────────────────────────
function useFadeUp() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { el.classList.add("visible"); obs.disconnect(); } },
      { threshold: 0.12 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return ref;
}

// ─── Counter animation hook ───────────────────────────────────────────────────
function useCountUp(target: number, suffix = "") {
  const [value, setValue] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          let start = 0;
          const duration = 1200;
          const step = (timestamp: number) => {
            if (!start) start = timestamp;
            const progress = Math.min((timestamp - start) / duration, 1);
            setValue(Math.floor(progress * target));
            if (progress < 1) requestAnimationFrame(step);
            else setValue(target);
          };
          requestAnimationFrame(step);
          obs.disconnect();
        }
      },
      { threshold: 0.5 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [target]);
  return { ref, display: value + suffix };
}

// ─── Nav ──────────────────────────────────────────────────────────────────────
function Nav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const links = [
    { label: "The Problem", href: "#problem" },
    { label: "Our Approach", href: "#approach" },
    { label: "The Roundtable", href: "/roundtable" },
    { label: "Platform", href: "#platform" },
    { label: "Who We Serve", href: "#who" },
    { label: "About Us", href: "/about" },
  ];

  return (
    <nav
      role="navigation"
      aria-label="Main navigation"
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        backgroundColor: scrolled ? "oklch(0.24 0.07 155 / 0.97)" : "oklch(0.24 0.07 155)",
        backdropFilter: scrolled ? "blur(8px)" : "none",
        boxShadow: scrolled ? "0 2px 20px oklch(0 0 0 / 0.3)" : "none",
        borderBottom: "1px solid oklch(1 0 0 / 0.08)",
      }}
    >
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 bg-gold text-dark-text font-bold">
        Skip to main content
      </a>
      <div className="container flex items-center justify-between" style={{ height: "68px" }}>
        {/* Logo */}
        <a href="#hero" aria-label="Business Owner Platform — Home" className="flex-shrink-0">
          <img
            src={BOP_LOGO}
            alt="Business Owner Platform"
            style={{ height: "44px", width: "auto" }}
          />
        </a>

        {/* Desktop links */}
        <ul className="hidden lg:flex items-center gap-6 list-none m-0 p-0">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="text-cream font-subhead hover:text-gold transition-colors duration-200"
                style={{ fontSize: "0.72rem", letterSpacing: "0.1em" }}
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        {/* CTAs */}
        <div className="hidden lg:flex items-center gap-2">
          <a href="/snapshot" className="btn-outline" style={{ padding: "0.6rem 1.25rem", fontSize: "0.72rem" }}>
            Free Business Assessment
          </a>
          <a href="/roundtable" className="btn-primary" style={{ padding: "0.6rem 1.25rem", fontSize: "0.72rem" }}>
            Attend the Roundtable
          </a>
        </div>

        {/* Mobile toggle */}
        <button
          className="lg:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setOpen(!open)}
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label="Toggle navigation"
        >
          <span className="block w-6 h-0.5 bg-cream transition-all duration-200" style={{ transform: open ? "rotate(45deg) translate(4px, 4px)" : "none" }} />
          <span className="block w-6 h-0.5 bg-cream transition-all duration-200" style={{ opacity: open ? 0 : 1 }} />
          <span className="block w-6 h-0.5 bg-cream transition-all duration-200" style={{ transform: open ? "rotate(-45deg) translate(4px, -4px)" : "none" }} />
        </button>
      </div>

      {/* Mobile drawer */}
      <div
        id="mobile-nav"
        aria-hidden={!open}
        className="lg:hidden overflow-hidden transition-all duration-300"
        style={{ maxHeight: open ? "400px" : "0", backgroundColor: "oklch(0.20 0.07 155)" }}
      >
        <div className="container py-4 flex flex-col gap-1">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="text-cream font-subhead py-3 border-b border-white/10 hover:text-gold transition-colors"
              style={{ fontSize: "0.8rem", letterSpacing: "0.1em" }}
            >
              {l.label}
            </a>
          ))}
          <a href="/snapshot" onClick={() => setOpen(false)} className="btn-outline mt-4" style={{ justifyContent: "center" }}>
            Free Business Assessment
          </a>
          <a href="/roundtable" onClick={() => setOpen(false)} className="btn-primary mt-2" style={{ justifyContent: "center" }}>
            Attend the Roundtable
          </a>
        </div>
      </div>
    </nav>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────────────────
function Hero() {
  const stat1 = useCountUp(80, "%");
  const stat2 = useCountUp(1000, "+");
  return (
    <section
      id="hero"
      aria-label="Hero"
      style={{
        background: "linear-gradient(135deg, oklch(0.20 0.08 155) 0%, oklch(0.28 0.07 155) 60%, oklch(0.35 0.09 155) 100%)",
        paddingTop: "68px",
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Subtle texture overlay */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "radial-gradient(circle at 70% 50%, oklch(0.65 0.10 75 / 0.06) 0%, transparent 60%)",
        pointerEvents: "none",
      }} />

      <div className="container relative z-10 py-20">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left: copy */}
          <div>
            <p className="section-label text-gold mb-4">A Platform of Northstar Value Group</p>
            <h1 className="font-headline text-cream mb-6" style={{ fontSize: "clamp(2.4rem, 5vw, 4rem)", lineHeight: 1.1 }}>
              A Better Business<br />
              to Own Today.<br />
              <span className="text-gold">A More Valuable<br />Business Tomorrow.</span>
            </h1>
            <p className="text-cream/80 mb-10 max-w-lg" style={{ fontSize: "1.05rem", lineHeight: 1.7 }}>
              Most business owners have no real visibility into what their company is worth or what drives that value. We bring honest clarity — early enough to act on it.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a href="/roundtable" className="btn-primary">Attend the Growth and Exit Roundtable</a>
              <a href="#platform" className="btn-outline">See How It Works</a>
            </div>
          </div>

          {/* Right: stat card */}
          <div className="hidden lg:block">
            <div style={{
              background: "oklch(0.18 0.06 155 / 0.7)",
              border: "1px solid oklch(0.65 0.10 75 / 0.3)",
              padding: "2.5rem",
              backdropFilter: "blur(8px)",
            }}>
              <div className="mb-8">
                <span ref={stat1.ref} className="stat-number">{stat1.display}</span>
                <p className="text-cream/70 mt-2" style={{ fontSize: "0.9rem" }}>
                  of businesses that go to market never successfully sell — not because they are bad businesses, but because they were never made ready.
                </p>
              </div>
              <div className="border-t border-white/10 pt-8 mb-8">
                <span className="stat-number">3–5</span>
                <p className="text-cream/70 mt-2" style={{ fontSize: "0.9rem" }}>
                  years earlier than they thought — that's when the owners who exit on their terms started the conversation.
                </p>
              </div>
              <div className="border-t border-white/10 pt-8">
                <span ref={stat2.ref} className="stat-number">{stat2.display}</span>
                <p className="text-cream/70 mt-2" style={{ fontSize: "0.9rem" }}>
                  business owners we are committed to helping successfully transition their businesses in the next five years.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Problem ──────────────────────────────────────────────────────────────────
function Problem() {
  const ref = useFadeUp();
  return (
    <section id="problem" aria-labelledby="problem-heading" className="bg-cream py-24">
      <div className="container">
        <div ref={ref} className="fade-up grid lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          <div>
            <p className="section-label text-value-green">The Reality Check</p>
            <span className="gold-rule" />
            <h2 id="problem-heading" className="font-headline text-value-green mb-6" style={{ fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)" }}>
              You Don't Have a Selling Problem. You Have a Readiness Problem.
            </h2>
            <p className="mb-5" style={{ color: "oklch(0.35 0.02 65)", lineHeight: 1.75 }}>
              Most business owners have built something real. But when it comes to understanding what their business is actually worth — or what a buyer would actually see — they are flying blind.
            </p>
            <p style={{ color: "oklch(0.35 0.02 65)", lineHeight: 1.75 }}>
              They can't show predictable revenue growth. They are the single point of failure in their own company. They don't know where their best customers come from. And they have no roadmap for what to do about any of it.
            </p>
            <p className="mt-5 font-semibold" style={{ color: "oklch(0.24 0.07 155)" }}>
              The Business Owner Platform fixes that — whether an exit is five years away or never crosses your mind.
            </p>
          </div>
          <div>
            <div style={{
              background: "oklch(0.24 0.07 155)",
              padding: "2.5rem",
              position: "relative",
            }}>
              <span className="gold-rule" />
              <blockquote className="text-cream mb-8" style={{ fontSize: "1.15rem", lineHeight: 1.7, fontStyle: "italic" }}>
                "80% of businesses that go to market never successfully sell — not because they are bad businesses, but because they were never made ready."
              </blockquote>
              <div className="border-t border-white/15 pt-6">
                <blockquote className="text-cream/80" style={{ fontSize: "1rem", lineHeight: 1.7, fontStyle: "italic" }}>
                  "The owners who exit on their terms started the conversation 3–5 years earlier than they thought they needed to."
                </blockquote>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Two Doors ────────────────────────────────────────────────────────────────
function TwoDoors() {
  const ref = useFadeUp();
  return (
    <section id="approach" aria-labelledby="doors-heading" style={{ background: "oklch(0.88 0.02 80)" }} className="py-24">
      <div className="container">
        <div className="text-center mb-14">
          <p className="section-label text-value-green">Two Doors. One Destination.</p>
          <span className="gold-rule mx-auto" />
          <h2 id="doors-heading" className="font-headline text-value-green" style={{ fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)" }}>
            Business Owners Come to Us From Two Very Different Starting Points
          </h2>
          <p className="mt-4 max-w-2xl mx-auto" style={{ color: "oklch(0.4 0.02 65)" }}>
            Both are welcome. Both need exactly the same work done on their business.
          </p>
        </div>
        <div ref={ref} className="fade-up grid md:grid-cols-2 gap-0">
          {/* Door 1 */}
          <div style={{ background: "oklch(0.24 0.07 155)", padding: "3rem 2.5rem", borderRight: "3px solid oklch(0.65 0.10 75)" }}>
            <p className="section-label text-gold mb-4">Door One</p>
            <h3 className="font-headline text-cream mb-4" style={{ fontSize: "1.6rem" }}>The Exit-Aware Owner</h3>
            <p className="text-cream/80 mb-6" style={{ lineHeight: 1.75 }}>
              Knows time is finite. Wants to be ready when the moment comes. Quietly worried the business isn't as sellable as they believe. Wants a clear roadmap — not a sales pitch.
            </p>
            <p className="text-gold/90 mb-6" style={{ fontSize: "0.9rem" }}>
              Motivated by building a business a buyer actually wants.
            </p>
            <div style={{ borderLeft: "3px solid oklch(0.65 0.10 75)", paddingLeft: "1rem" }}>
              <p className="text-cream font-semibold italic">"Build a business worth buying."</p>
            </div>
          </div>
          {/* Door 2 */}
          <div style={{ background: "oklch(0.30 0.08 155)", padding: "3rem 2.5rem" }}>
            <p className="section-label text-gold mb-4">Door Two</p>
            <h3 className="font-headline text-cream mb-4" style={{ fontSize: "1.6rem" }}>The Growth-Minded Owner</h3>
            <p className="text-cream/80 mb-6" style={{ lineHeight: 1.75 }}>
              Not thinking about exit — yet. Tired of being the bottleneck. Wants the business to run better, grow more predictably, and stop depending on them for every decision.
            </p>
            <p className="text-gold/90 mb-6" style={{ fontSize: "0.9rem" }}>
              Motivated by reclaiming their time and seeing the numbers move.
            </p>
            <div style={{ borderLeft: "3px solid oklch(0.65 0.10 75)", paddingLeft: "1rem" }}>
              <p className="text-cream font-semibold italic">"Build a business that works for you."</p>
            </div>
          </div>
        </div>
        {/* Unifier */}
        <div style={{ background: "oklch(0.65 0.10 75)", padding: "1.5rem 2.5rem", textAlign: "center" }}>
          <p className="font-headline" style={{ color: "oklch(0.18 0.02 65)", fontSize: "1rem", letterSpacing: "0.02em" }}>
            Both owners need exactly the same thing: a more valuable, less owner-dependent, analytically clear business. The platform delivers that.
          </p>
        </div>
      </div>
    </section>
  );
}

// ─── Three Pillars ────────────────────────────────────────────────────────────
function ThreePillars() {
  const ref = useFadeUp();
  const pillars = [
    {
      num: "01",
      title: "Operational Freedom",
      body: "Build systems and processes so the business runs without you. Stop being the bottleneck in your own company. A business that operates independently is both more enjoyable to own and far more attractive to a buyer.",
    },
    {
      num: "02",
      title: "Financial & Analytical Clarity",
      body: "Know where your revenue comes from, where your leads originate, and what is actually driving growth in your business. Most owners can't answer the most important questions about their business. We fix that.",
    },
    {
      num: "03",
      title: "Measurable Value Growth",
      body: "Track and grow the real value of your business over time — so you can see the progress and prove it to anyone who asks. Value is built deliberately, measured consistently, and compounded over time.",
    },
  ];
  return (
    <section id="pillars" aria-labelledby="pillars-heading" className="bg-cream py-24">
      <div className="container">
        <div className="mb-14">
          <p className="section-label text-value-green">Our Approach</p>
          <span className="gold-rule" />
          <h2 id="pillars-heading" className="font-headline text-value-green" style={{ fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", maxWidth: "600px" }}>
            The Three Value-Building Pillars
          </h2>
          <p className="mt-4 max-w-xl" style={{ color: "oklch(0.4 0.02 65)" }}>
            Everything we teach flows through three pillars — whether you are preparing for an exit or simply building a better business to own.
          </p>
        </div>
        <div ref={ref} className="fade-up grid md:grid-cols-3 gap-0">
          {pillars.map((p, i) => (
            <div
              key={p.num}
              style={{
                background: i % 2 === 1 ? "oklch(0.24 0.07 155)" : "oklch(0.20 0.07 155)",
                padding: "2.5rem 2rem",
                borderRight: i < 2 ? "1px solid oklch(1 0 0 / 0.1)" : "none",
              }}
            >
              <span className="font-headline text-gold/50 block mb-4" style={{ fontSize: "2.5rem", lineHeight: 1 }}>{p.num}</span>
              <h3 className="font-headline text-cream mb-4" style={{ fontSize: "1.3rem" }}>{p.title}</h3>
              <p className="text-cream/75" style={{ lineHeight: 1.75, fontSize: "0.95rem" }}>{p.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── What We Teach ────────────────────────────────────────────────────────────
function WhatWeTeach() {
  const ref = useFadeUp();
  const items = [
    { title: "Reality Check", body: "Most business owners have no real visibility into what their company is worth or what drives that value. We bring honest clarity — early enough to act on it." },
    { title: "Operational Freedom", body: "A business that runs without the owner is both more enjoyable to own and more attractive to a buyer. We help owners build real systems, not just document what they already do." },
    { title: "Know Your Numbers", body: "Where do my best clients come from? What does my revenue look like in three years? What is my business actually worth today? We fix the blind spots that most owners don't even know they have." },
    { title: "Risk Drives Value", body: "Every source of risk in your business suppresses its value — for you today and for a buyer tomorrow. Reducing risk makes the business more profitable, more stable, and more valuable." },
    { title: "Value Is Built, Not Hoped For", body: "Whether you are planning to exit or planning to grow, value doesn't happen by accident. It is built deliberately, measured consistently, and compounded over time." },
    { title: "Education First, Always", body: "A safe, no-pressure environment with no hidden selling. We teach what buyers look for, what makes a business truly valuable, and what owners can do about it — right now." },
  ];
  return (
    <section id="teach" aria-labelledby="teach-heading" style={{ background: "oklch(0.18 0.06 155)" }} className="py-24">
      <div className="container">
        <div className="mb-14">
          <p className="section-label text-gold">What We Teach</p>
          <span className="gold-rule" />
          <h2 id="teach-heading" className="font-headline text-cream" style={{ fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", maxWidth: "600px" }}>
            The Core Messaging Pillars
          </h2>
          <p className="mt-4 max-w-xl text-cream/70" style={{ fontSize: "0.95rem" }}>
            Every piece of communication teaches the owner something. We lead with insight, not with a pitch.
          </p>
        </div>
        <div ref={ref} className="fade-up grid md:grid-cols-2 lg:grid-cols-3 gap-px" style={{ background: "oklch(1 0 0 / 0.08)" }}>
          {items.map((item) => (
            <div key={item.title} style={{ background: "oklch(0.18 0.06 155)", padding: "2rem" }}>
              <h4 className="font-headline text-gold mb-3" style={{ fontSize: "1.1rem" }}>{item.title}</h4>
              <p className="text-cream/70" style={{ lineHeight: 1.75, fontSize: "0.9rem" }}>{item.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Roundtable ───────────────────────────────────────────────────────────────
function Roundtable() {
  const ref = useFadeUp();
  const features = [
    "Business valuation basics and what buyers actually look for",
    "The eight value drivers that determine what your business is worth",
    "Common reasons businesses fail to sell — and what to do about it",
    "What owners can do right now to build a more valuable business",
    "A team of advisors covering financial, legal, operational, and strategic questions",
    "Natural, permission-based follow-up — no pressure, no pitch",
  ];
  return (
    <section id="roundtable" aria-labelledby="roundtable-heading" className="bg-cream py-24">
      <div className="container">
        <div ref={ref} className="fade-up grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <div>
            <p className="section-label text-value-green">The Bridge Event</p>
            <span className="gold-rule" />
            <h2 id="roundtable-heading" className="font-headline text-value-green mb-2" style={{ fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)" }}>
              Growth and Exit Roundtable
            </h2>
            <p className="text-gold font-semibold mb-6" style={{ fontSize: "0.9rem", letterSpacing: "0.05em" }}>
              No pitch. No sales. Just the information every business owner needs.
            </p>
            <p className="mb-8" style={{ color: "oklch(0.35 0.02 65)", lineHeight: 1.75 }}>
              The Growth and Exit Roundtable is where business owners first hear the truth — and where the right advisors are already in the room. These events are the primary moment of education and relationship-building for business owners.
            </p>
            <ul className="space-y-3 mb-10">
              {features.map((f) => (
                <li key={f} className="flex gap-3 items-start" style={{ color: "oklch(0.35 0.02 65)", fontSize: "0.95rem", lineHeight: 1.6 }}>
                  <span className="text-gold mt-1 flex-shrink-0">✦</span>
                  {f}
                </li>
              ))}
            </ul>
            <a href="/roundtable" className="btn-primary">Reserve Your Seat</a>
          </div>
          <div className="flex flex-col gap-6">
            {/* Logo card */}
            <div style={{
              background: "oklch(0.16 0.06 230)",
              padding: "2.5rem 2rem",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}>
              <img
                src={GER_LOGO}
                alt="Growth and Exit Roundtable — Presented by NorthStar Value Group"
                style={{ width: "100%", maxWidth: "420px", height: "auto", display: "block" }}
              />
            </div>
            {/* Stats bar */}
            <div style={{
              background: "oklch(0.24 0.07 155)",
              padding: "1.75rem 2rem",
            }}>
              <p className="text-cream/70 mb-4" style={{ fontSize: "0.9rem", lineHeight: 1.7 }}>
                Hosted by Trusted Advisor Collaborative teams across the US. Local markets. Multi-advisor teams. Pure education.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {[["Free", "No cost to attend"], ["2–3 hrs", "Focused education"], ["Local", "US markets"], ["No pitch", "Pure education"]].map(([stat, label]) => (
                  <div key={stat} style={{ borderTop: "2px solid oklch(0.65 0.10 75 / 0.4)", paddingTop: "0.75rem" }}>
                    <span className="font-headline text-gold block" style={{ fontSize: "1.3rem" }}>{stat}</span>
                    <span className="text-cream/60" style={{ fontSize: "0.8rem" }}>{label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Platform ─────────────────────────────────────────────────────────────────
function Platform() {
  const ref = useFadeUp();
  const steps = [
    {
      num: "01",
      label: "Step 1 — Awareness",
      title: "Free Education & Resources",
      body: "Start with no commitment. Access articles, videos, and resources that teach owners what buyers actually look for and how businesses are valued.",
      items: ["Articles on business valuation fundamentals", "Videos on the eight value drivers", "Owner-focused educational content", "Exit Readiness Assessment tool"],
    },
    {
      num: "02",
      label: "Step 2 — Engagement",
      title: "Growth and Exit Roundtables",
      body: "The primary call-to-action. Educational roundtables hosted by Trusted Advisor Collaborative teams that help owners understand their business's true market value.",
      items: ["Low-commitment, high-value events", "Local markets across the US", "Multi-advisor teams in the room", "No sales pitch — pure education"],
    },
    {
      num: "03",
      label: "Step 3 — Implementation",
      title: "Member Platform Access",
      body: "For Roundtable alumni and ongoing members, a deeper engagement environment with tools, resources, and community.",
      items: ["Value driver checklists and scorecards", "Risk assessment tools", "Monthly educational sessions", "Vetted advisor network access", "Peer community of fellow owners"],
    },
  ];
  return (
    <section id="platform" aria-labelledby="platform-heading" style={{ background: "oklch(0.88 0.02 80)" }} className="py-24">
      <div className="container">
        <div className="mb-14">
          <p className="section-label text-value-green">The Platform</p>
          <span className="gold-rule" />
          <h2 id="platform-heading" className="font-headline text-value-green" style={{ fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", maxWidth: "600px" }}>
            Your Path to a More Valuable Business
          </h2>
          <p className="mt-4 max-w-xl" style={{ color: "oklch(0.4 0.02 65)" }}>
            The Business Owner Platform is designed as a top-of-funnel authority builder. We educate owners early — long before they are thinking about an exit.
          </p>
        </div>
        <div ref={ref} className="fade-up grid md:grid-cols-3 gap-8">
          {steps.map((s) => (
            <div key={s.num} style={{ background: "white", padding: "2.5rem 2rem", borderTop: "4px solid oklch(0.65 0.10 75)" }}>
              <span className="font-headline text-gold/40 block mb-2" style={{ fontSize: "2rem" }}>{s.num}</span>
              <p className="section-label text-value-green mb-2">{s.label}</p>
              <h3 className="font-headline text-value-green mb-4" style={{ fontSize: "1.25rem" }}>{s.title}</h3>
              <p className="mb-6" style={{ color: "oklch(0.4 0.02 65)", fontSize: "0.9rem", lineHeight: 1.75 }}>{s.body}</p>
              <ul className="space-y-2">
                {s.items.map((item) => (
                  <li key={item} className="flex gap-2 items-start" style={{ color: "oklch(0.4 0.02 65)", fontSize: "0.85rem", lineHeight: 1.6 }}>
                    <span className="text-gold mt-0.5 flex-shrink-0">✦</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Who We Serve ─────────────────────────────────────────────────────────────
function WhoWeServe() {
  const ref = useFadeUp();
  const demos = [
    { stat: "5–15", label: "Years In", desc: "Past the startup phase. Profitable but not yet optimized for transferability." },
    { stat: "5–50", label: "Employees", desc: "Owner-operated businesses across service, professional, and trades industries." },
    { stat: "$1M–$25M", label: "Revenue", desc: "Businesses with real value to protect, grow, and eventually transfer." },
    { stat: "US-Based", label: "Owners", desc: "Primarily US-based, owner-operated businesses across all industries." },
  ];
  return (
    <section id="who" aria-labelledby="who-heading" className="bg-cream py-24">
      <div className="container">
        <div className="mb-14">
          <p className="section-label text-value-green">Who We Serve</p>
          <span className="gold-rule" />
          <h2 id="who-heading" className="font-headline text-value-green" style={{ fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", maxWidth: "600px" }}>
            Built for the Business Owner Who Is Ready to Hear the Truth
          </h2>
        </div>
        <div ref={ref} className="fade-up grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {demos.map((d) => (
            <div key={d.stat} style={{ background: "oklch(0.24 0.07 155)", padding: "2rem 1.5rem" }}>
              <span className="font-headline text-gold block mb-1" style={{ fontSize: "1.8rem", lineHeight: 1 }}>{d.stat}</span>
              <span className="section-label text-cream/60 block mb-3">{d.label}</span>
              <p className="text-cream/75" style={{ fontSize: "0.85rem", lineHeight: 1.65 }}>{d.desc}</p>
            </div>
          ))}
        </div>
        {/* NOT for */}
        <div style={{ background: "oklch(0.88 0.02 80)", border: "1px solid oklch(0.82 0.02 80)", padding: "2rem 2.5rem" }}>
          <h3 className="font-headline text-value-green mb-4" style={{ fontSize: "1.1rem" }}>This Is NOT For:</h3>
          <ul className="space-y-2">
            {[
              "Owners in immediate sale mode who need a broker (we'll refer them)",
              "Owners not open to an honest assessment of where their business stands",
              "Anyone looking for a quick-fix valuation boost without doing the real work",
            ].map((item) => (
              <li key={item} className="flex gap-3 items-start" style={{ color: "oklch(0.4 0.02 65)", fontSize: "0.9rem", lineHeight: 1.6 }}>
                <span style={{ color: "oklch(0.55 0.18 27)", marginTop: "0.1rem", flexShrink: 0 }}>✗</span>
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

// ─── FAQ ──────────────────────────────────────────────────────────────────────
const faqs = [
  { q: "What is the Business Owner Platform?", a: "The Business Owner Platform is an educational platform designed to help business owners build more valuable, less owner-dependent businesses. We provide resources, events, and tools that give owners honest clarity about what their business is worth and what drives that value — whether they are thinking about an exit or simply want to build a better business." },
  { q: "What is a Growth and Exit Roundtable?", a: "A Growth and Exit Roundtable is a free, educational event hosted by a team of advisors covering financial, legal, operational, and strategic topics. There is no sales pitch — just honest, practical information about business valuation, the eight value drivers, and what owners can do right now to build a more valuable business." },
  { q: "Why do most businesses fail to sell?", a: "80% of businesses that go to market never successfully sell — not because they are bad businesses, but because they were never made ready. Most owners have not addressed the key value drivers that buyers look for: predictable revenue, documented systems, a management team that doesn't depend on the owner, and clear financial records." },
  { q: "Who is the Business Owner Platform designed for?", a: "The platform is designed for US-based, owner-operated businesses with 5–50 employees and $1M–$25M in revenue, typically 5–15 years into their journey. Both exit-aware owners and growth-minded owners are welcome — both need the same foundational work done on their business." },
  { q: "What are the eight value drivers that buyers care about?", a: "The eight value drivers include: financial performance, growth potential, the Switzerland structure (owner independence), the valuation teeter-totter (recurring vs. one-time revenue), the hierarchy of recurring revenue, customer satisfaction, hub and spoke (key person dependency), and monopoly control. We teach all eight in our Roundtables and platform resources." },
  { q: "How early should a business owner start preparing for an exit?", a: "The owners who exit on their terms started the conversation 3–5 years earlier than they thought they needed to. The earlier you start, the more options you have — and the more value you can build before the moment of transition arrives." },
  { q: "Does the Business Owner Platform sell businesses or charge for advice?", a: "No. The Business Owner Platform is an educational platform, not a brokerage or advisory firm. We do not sell businesses, charge for advice, or earn commissions. Our goal is to educate owners early so they can make informed decisions and connect with the right advisors when the time comes." },
  { q: "What is the difference between exit planning and exit readiness?", a: "Exit planning is a transactional process — it begins when you decide to sell. Exit readiness is a state of business health — it means your business could be sold, transferred, or operated without you at any time. We focus on exit readiness, which benefits every owner regardless of their timeline." },
];

function FAQ() {
  const [open, setOpen] = useState<number | null>(null);
  const ref = useFadeUp();
  return (
    <section id="faq" aria-labelledby="faq-heading" style={{ background: "oklch(0.18 0.06 155)" }} className="py-24">
      <div className="container">
        <div className="mb-14">
          <p className="section-label text-gold">Common Questions</p>
          <span className="gold-rule" />
          <h2 id="faq-heading" className="font-headline text-cream" style={{ fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", maxWidth: "600px" }}>
            Frequently Asked Questions
          </h2>
          <p className="mt-4 text-cream/70" style={{ fontSize: "0.95rem" }}>
            Honest answers to the questions every business owner should be asking — but often isn't.
          </p>
        </div>
        <div ref={ref} className="fade-up max-w-3xl">
          {faqs.map((faq, i) => (
            <div key={i} className="faq-item on-dark">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                aria-expanded={open === i}
                className="w-full flex justify-between items-start gap-4 py-5 text-left"
                style={{ background: "none", border: "none", cursor: "pointer" }}
              >
                <span className="font-headline text-cream" style={{ fontSize: "1.05rem", lineHeight: 1.4 }}>{faq.q}</span>
                <span className="text-gold flex-shrink-0 mt-1" style={{ fontSize: "1.2rem", transition: "transform 0.2s", transform: open === i ? "rotate(45deg)" : "none" }}>+</span>
              </button>
              <div style={{
                maxHeight: open === i ? "400px" : "0",
                overflow: "hidden",
                transition: "max-height 0.3s ease-out",
              }}>
                <p className="text-cream/75 pb-5" style={{ fontSize: "0.95rem", lineHeight: 1.75 }}>{faq.a}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Mission ──────────────────────────────────────────────────────────────────
function Mission() {
  const ref = useFadeUp();
  const values = ["Owner-First", "Honest Clarity", "Education Before Transaction", "Long-Term Thinking", "Measurable Progress"];
  return (
    <section id="mission" aria-labelledby="mission-heading" style={{ background: "oklch(0.24 0.07 155)" }} className="py-24">
      <div className="container">
        <div ref={ref} className="fade-up grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <div>
            <p className="section-label text-gold">Our Mission</p>
            <span className="gold-rule" />
            <blockquote className="font-headline text-cream mb-8" style={{ fontSize: "clamp(1.4rem, 3vw, 2rem)", lineHeight: 1.35, fontStyle: "italic" }}>
              "Whether you want to grow it, hand it off, or sell it one day — a more valuable business is always the answer. That's what we help you build."
            </blockquote>
            <p className="text-cream/75 mb-8" style={{ lineHeight: 1.75 }}>
              To provide business owners with objective guidance and education that increases their chances of a successful, high-value exit — on their terms. We educate owners early so they can exit intentionally, not by accident.
            </p>
            <a href="/roundtable" className="btn-outline">Learn About the Roundtable</a>
          </div>
          <div>
            <h3 className="font-headline text-gold mb-6" style={{ fontSize: "1.1rem", letterSpacing: "0.05em" }}>CORE VALUES</h3>
            <div className="space-y-3">
              {values.map((v, i) => (
                <div key={v} className="flex items-center gap-4" style={{ borderBottom: "1px solid oklch(1 0 0 / 0.1)", paddingBottom: "0.75rem" }}>
                  <span className="font-headline text-gold/50" style={{ fontSize: "0.9rem", width: "1.5rem", flexShrink: 0 }}>0{i + 1}</span>
                  <span className="font-headline text-cream" style={{ fontSize: "1.05rem" }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Final CTA ────────────────────────────────────────────────────────────────
function FinalCTA() {
  const ref = useFadeUp();
  return (
    <section id="cta" aria-label="Call to action" style={{ background: "oklch(0.65 0.10 75)" }} className="py-24">
      <div className="container">
        <div ref={ref} className="fade-up text-center max-w-3xl mx-auto">
          <h2 className="font-headline mb-6" style={{ color: "oklch(0.18 0.02 65)", fontSize: "clamp(2rem, 4vw, 3rem)", lineHeight: 1.1 }}>
            Hope Is Not an Exit Strategy.
          </h2>
          <p className="mb-10" style={{ color: "oklch(0.25 0.02 65)", fontSize: "1.1rem", lineHeight: 1.75 }}>
            The owners who exit on their terms started the conversation years before they thought they needed to. The first step is a Growth and Exit Roundtable — free, honest, and built for business owners who are ready to hear the truth.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/roundtable" className="btn-outline-dark">Attend the Roundtable</a>
            <a href="/snapshot" className="btn-outline-dark">Free Exit Readiness Snapshot</a>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer role="contentinfo" style={{ background: "oklch(0.16 0.06 155)", borderTop: "1px solid oklch(1 0 0 / 0.08)" }}>
      <div className="container py-16">
        <div className="grid md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <img src={BOP_LOGO} alt="Business Owner Platform" style={{ height: "48px", width: "auto", marginBottom: "1rem" }} />
            <p className="text-cream/60" style={{ fontSize: "0.85rem", lineHeight: 1.7 }}>
              A platform of Northstar Value Group. Helping business owners build more valuable, less owner-dependent businesses.
            </p>
          </div>
          {/* Platform */}
          <div>
            <h5 className="font-subhead text-gold mb-4">Platform</h5>
            <ul className="space-y-2 list-none p-0 m-0">
              {[["The Problem", "#problem"], ["Our Approach", "#approach"], ["Growth and Exit Roundtable", "/roundtable"], ["The Platform", "#platform"], ["Who We Serve", "#who"]].map(([label, href]) => (
                <li key={href}><a href={href} className="text-cream/60 hover:text-gold transition-colors" style={{ fontSize: "0.85rem" }}>{label}</a></li>
              ))}
            </ul>
          </div>
          {/* Resources */}
          <div>
            <h5 className="font-subhead text-gold mb-4">Resources</h5>
            <ul className="space-y-2 list-none p-0 m-0">
              {[["Exit Readiness Assessment", "#faq"], ["Value Driver Checklist", "#faq"], ["Educational Articles", "#faq"], ["Owner Resources", "#faq"], ["FAQ", "#faq"]].map(([label, href]) => (
                <li key={label}><a href={href} className="text-cream/60 hover:text-gold transition-colors" style={{ fontSize: "0.85rem" }}>{label}</a></li>
              ))}
            </ul>
          </div>
          {/* Connect */}
          <div>
            <h5 className="font-subhead text-gold mb-4">Connect</h5>
            <ul className="space-y-2 list-none p-0 m-0">
              {[["Attend the Roundtable", "/roundtable"], ["Contact Us", "#cta"], ["Exit Readiness Snapshot", "/snapshot"]].map(([label, href]) => (
                <li key={label}><a href={href} className="text-cream/60 hover:text-gold transition-colors" style={{ fontSize: "0.85rem" }}>{label}</a></li>
              ))}
            </ul>
          </div>
        </div>
        {/* Bottom */}
        <div style={{ borderTop: "1px solid oklch(1 0 0 / 0.08)", paddingTop: "2rem" }} className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-3">
            <img src={NVG_LOGO} alt="Northstar Value Group" style={{ height: "28px", width: "auto", opacity: 0.7 }} />
            <span className="text-cream/40" style={{ fontSize: "0.8rem" }}>A Northstar Value Group Platform</span>
          </div>
          <div className="flex gap-6">
            <a href="#" className="text-cream/40 hover:text-cream/70 transition-colors" style={{ fontSize: "0.8rem" }}>Privacy Policy</a>
            <a href="#" className="text-cream/40 hover:text-cream/70 transition-colors" style={{ fontSize: "0.8rem" }}>Terms of Use</a>
            <span className="text-cream/30" style={{ fontSize: "0.8rem" }}>© {year} Northstar Value Group</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─── Schema.org JSON-LD ───────────────────────────────────────────────────────
function SchemaMarkup() {
  const schema = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": "https://businessownerplatform.com/#organization",
        "name": "Business Owner Platform",
        "url": "https://businessownerplatform.com/",
        "logo": BOP_LOGO,
        "description": "An educational platform helping business owners build more valuable, less owner-dependent businesses through the Growth and Exit Roundtable and ongoing resources.",
        "parentOrganization": { "@type": "Organization", "name": "Northstar Value Group" },
        "knowsAbout": ["Business Valuation", "Exit Planning", "Value Drivers", "Operational Freedom", "Exit Readiness"],
      },
      {
        "@type": "FAQPage",
        "mainEntity": faqs.map((f) => ({
          "@type": "Question",
          "name": f.q,
          "acceptedAnswer": { "@type": "Answer", "text": f.a },
        })),
      },
    ],
  };
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />;
}

// ─── Main export ──────────────────────────────────────────────────────────────
export default function Home() {
  return (
    <>
      <SchemaMarkup />
      <a href="#main" className="sr-only focus:not-sr-only">Skip to main content</a>
      <Nav />
      <main id="main">
        <Hero />
        <Problem />
        <TwoDoors />
        <ThreePillars />
        <WhatWeTeach />
        <Roundtable />
        <Platform />
        <WhoWeServe />
        <FAQ />
        <Mission />
        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
