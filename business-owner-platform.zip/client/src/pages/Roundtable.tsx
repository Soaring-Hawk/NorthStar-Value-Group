/**
 * Business Owner Platform — Growth and Exit Roundtable Landing Page
 * Design: Institutional Authority (matches site-wide design)
 * Colors: Value Green #1A3D2E | Gold #B8922E | Cream #FAF7F2
 * Fonts: Oswald (headlines) | Barlow (subheads/body)
 * Brief: GrowthandExitRoundtableWebsiteContentBrief.md
 * Rules: No em dashes, second person, 3-sentence max paragraphs, $997 visible
 */

import { useEffect, useRef, useState } from "react";

const GER_LOGO = "/manus-storage/growth_exit_roundtable_logo_8b6c2ceb.png";
const BOP_LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/AAhEwqRgJGZhnRtZwJrWVS/bop_logo_baa7a023.png";
const NVG_LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/AAhEwqRgJGZhnRtZwJrWVS/nvg_logo_7a591d90.png";

function useFadeUp() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { el.classList.add("visible"); obs.disconnect(); } },
      { threshold: 0.1 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return ref;
}

// ─── Nav ──────────────────────────────────────────────────────────────────────
function Nav() {
  const [open, setOpen] = useState(false);
  const navLinks = [
    { label: "The Program", href: "#program" },
    { label: "What You Get", href: "#modules" },
    { label: "How It Works", href: "#how" },
    { label: "Investment", href: "#investment" },
    { label: "FAQ", href: "#faq" },
  ];
  return (
    <nav className="site-nav" role="navigation" aria-label="Main navigation" style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 1000,
      background: "oklch(0.16 0.06 155 / 0.97)",
      backdropFilter: "blur(8px)",
      borderBottom: "1px solid oklch(1 0 0 / 0.08)",
      height: "64px", display: "flex", alignItems: "center",
    }}>
      <div className="container" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: "100%" }}>
        <a href="/" aria-label="Business Owner Platform — Home" style={{ display: "flex", alignItems: "center", gap: "0.75rem", textDecoration: "none" }}>
          <img src={BOP_LOGO} alt="Business Owner Platform" style={{ height: "40px", width: "auto" }} />
        </a>
        <div className="hidden lg:flex" style={{ gap: "2rem", alignItems: "center" }}>
          {navLinks.map(({ label, href }) => (
            <a key={label} href={href} style={{
              color: "oklch(0.85 0.01 65)", fontSize: "0.72rem", fontFamily: "'Oswald', sans-serif",
              fontWeight: 500, letterSpacing: "0.1em", textTransform: "uppercase", textDecoration: "none",
              transition: "color 0.2s",
            }}
              onMouseEnter={e => (e.currentTarget.style.color = "oklch(0.65 0.10 75)")}
              onMouseLeave={e => (e.currentTarget.style.color = "oklch(0.85 0.01 65)")}
            >{label}</a>
          ))}
        </div>
        <div style={{ display: "flex", gap: "0.75rem", alignItems: "center" }}>
          <a href="/snapshot" className="hidden lg:inline-flex" style={{
            border: "1px solid oklch(0.65 0.10 75)", color: "oklch(0.65 0.10 75)",
            fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "0.72rem",
            letterSpacing: "0.1em", textTransform: "uppercase", textDecoration: "none",
            padding: "0.6rem 1.25rem", transition: "opacity 0.2s", background: "transparent",
          }}
            onMouseEnter={e => (e.currentTarget.style.opacity = "0.75")}
            onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
          >
            Free Business Assessment
          </a>
          <button
            className="lg:hidden"
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen(!open)}
            style={{ background: "none", border: "none", cursor: "pointer", padding: "0.5rem", display: "flex", flexDirection: "column", gap: "5px" }}
          >
            {[0, 1, 2].map(i => (
              <span key={i} style={{ display: "block", width: "22px", height: "2px", background: "oklch(0.85 0.01 65)", transition: "all 0.3s" }} />
            ))}
          </button>
        </div>
      </div>
      {open && (
        <div style={{
          position: "absolute", top: "64px", left: 0, right: 0,
          background: "oklch(0.16 0.06 155)", padding: "1.5rem",
          borderBottom: "1px solid oklch(1 0 0 / 0.08)", display: "flex", flexDirection: "column", gap: "1rem",
        }}>
          {navLinks.map(({ label, href }) => (
            <a key={label} href={href} onClick={() => setOpen(false)} style={{
              color: "oklch(0.85 0.01 65)", fontSize: "0.85rem", fontFamily: "'Oswald', sans-serif",
              fontWeight: 500, letterSpacing: "0.1em", textTransform: "uppercase", textDecoration: "none",
            }}>{label}</a>
          ))}
          <a href="/snapshot" onClick={() => setOpen(false)} style={{
            background: "oklch(0.65 0.10 75)", color: "oklch(0.16 0.06 155)",
            fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "0.8rem",
            letterSpacing: "0.1em", textTransform: "uppercase", textDecoration: "none",
            padding: "0.75rem 1.5rem", textAlign: "center", marginTop: "0.5rem",
          }}>Free Exit Snapshot</a>
        </div>
      )}
    </nav>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────────────────
function Hero() {
  return (
    <section aria-labelledby="hero-heading" style={{
      background: "oklch(0.16 0.06 155)",
      paddingTop: "120px", paddingBottom: "80px",
      position: "relative", overflow: "hidden",
    }}>
      <div style={{
        position: "absolute", inset: 0,
        background: "radial-gradient(ellipse at 70% 50%, oklch(0.24 0.07 155 / 0.6) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />
      <div className="container" style={{ position: "relative" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: "3rem", alignItems: "center" }}
          className="lg:grid-cols-2-custom">
          <div style={{ maxWidth: "600px" }}>
            <p style={{
              fontFamily: "'Oswald', sans-serif", fontWeight: 400, fontSize: "0.72rem",
              letterSpacing: "0.18em", textTransform: "uppercase", color: "oklch(0.65 0.10 75)",
              marginBottom: "1rem",
            }}>A NorthStar Value Group Program</p>
            <div style={{ width: "40px", height: "2px", background: "oklch(0.65 0.10 75)", marginBottom: "1.5rem" }} />
            <h1 id="hero-heading" style={{
              fontFamily: "'Oswald', sans-serif", fontWeight: 700,
              fontSize: "clamp(2.2rem, 5vw, 3.8rem)", lineHeight: 1.08,
              color: "oklch(0.97 0.005 65)", marginBottom: "1.5rem",
            }}>
              Build a Business Worth Buying.<br />
              <span style={{ color: "oklch(0.65 0.10 75)" }}>Exit on Your Terms.</span>
            </h1>
            <p style={{
              color: "oklch(0.78 0.01 65)", fontSize: "clamp(1rem, 1.5vw, 1.15rem)",
              lineHeight: 1.75, marginBottom: "2.5rem", maxWidth: "520px",
            }}>
              The Growth and Exit Roundtable is a structured six-module program for business owners who want to increase the value of their business, reduce their dependence on it, and prepare for a successful exit — whether that is three years away or ten.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: "1rem", alignItems: "flex-start" }}>
              <a href="/snapshot" style={{
                background: "oklch(0.65 0.10 75)", color: "oklch(0.16 0.06 155)",
                fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "0.85rem",
                letterSpacing: "0.12em", textTransform: "uppercase", textDecoration: "none",
                padding: "1rem 2rem", display: "inline-block", transition: "opacity 0.2s",
              }}
                onMouseEnter={e => (e.currentTarget.style.opacity = "0.85")}
                onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
              >
                Take the Free Exit Readiness Snapshot
              </a>
              <a href="#program" style={{
                color: "oklch(0.65 0.10 75)", fontFamily: "'Oswald', sans-serif",
                fontWeight: 500, fontSize: "0.78rem", letterSpacing: "0.12em",
                textTransform: "uppercase", textDecoration: "none",
                borderBottom: "1px solid oklch(0.65 0.10 75 / 0.4)", paddingBottom: "2px",
                transition: "border-color 0.2s",
              }}>
                Learn About the Program
              </a>
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
            <img
              src={GER_LOGO}
              alt="Growth and Exit Roundtable — Presented by NorthStar Value Group"
              style={{ width: "100%", maxWidth: "420px", height: "auto" }}
            />
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Problem ──────────────────────────────────────────────────────────────────
function Problem() {
  const ref = useFadeUp();
  const reasons = [
    "The owner is the business. Remove them, and the value disappears.",
    "The financials are messy, inconsistent, or hard for a buyer to trust.",
    "Revenue is too concentrated in one or two customers.",
    "There is no documented system for how anything gets done.",
    "The owner never defined what a successful exit actually looks like for them.",
  ];
  return (
    <section id="program" aria-labelledby="problem-heading" style={{ background: "oklch(0.97 0.005 65)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up" style={{ maxWidth: "760px", margin: "0 auto" }}>
          <p style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 400, fontSize: "0.72rem",
            letterSpacing: "0.18em", textTransform: "uppercase", color: "oklch(0.45 0.08 155)",
            marginBottom: "0.75rem",
          }}>The Reality</p>
          <div style={{ width: "40px", height: "2px", background: "oklch(0.65 0.10 75)", marginBottom: "1.5rem" }} />
          <h2 id="problem-heading" style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", lineHeight: 1.15,
            color: "oklch(0.22 0.07 155)", marginBottom: "1.5rem",
          }}>
            Most Business Owners Will Never Successfully Exit Their Business
          </h2>
          <p style={{ color: "oklch(0.35 0.02 65)", lineHeight: 1.8, marginBottom: "1rem", fontSize: "1rem" }}>
            Of all the businesses that go to market each year, roughly 70 to 80 percent never sell. They close, or the owner is forced to keep working past their intended exit date.
          </p>
          <p style={{ color: "oklch(0.35 0.02 65)", lineHeight: 1.8, marginBottom: "2rem", fontSize: "1rem" }}>
            It is not because they built bad businesses. It is because they never made their business ready.
          </p>
          <p style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "0.85rem",
            letterSpacing: "0.08em", textTransform: "uppercase", color: "oklch(0.22 0.07 155)",
            marginBottom: "1rem",
          }}>The most common reasons a business fails to sell:</p>
          <ul style={{ listStyle: "none", padding: 0, margin: "0 0 2rem 0", display: "flex", flexDirection: "column", gap: "0.75rem" }}>
            {reasons.map((r) => (
              <li key={r} style={{ display: "flex", gap: "0.75rem", alignItems: "flex-start", color: "oklch(0.35 0.02 65)", fontSize: "0.97rem", lineHeight: 1.65 }}>
                <span style={{ color: "oklch(0.55 0.15 25)", marginTop: "0.2rem", flexShrink: 0, fontWeight: 700 }}>✗</span>
                {r}
              </li>
            ))}
          </ul>
          <p style={{
            color: "oklch(0.22 0.07 155)", fontWeight: 600, lineHeight: 1.7,
            fontSize: "1rem", fontStyle: "italic",
            borderLeft: "4px solid oklch(0.65 0.10 75)", paddingLeft: "1.25rem",
          }}>
            If any of those sound familiar, you are not alone. And you are not out of time. But you do need a plan.
          </p>
        </div>
      </div>
    </section>
  );
}

// ─── Solution / NorthStar Value Path ─────────────────────────────────────────
function Solution() {
  const ref = useFadeUp();
  const stages = [
    { num: "01", name: "Discover", desc: "You learn what your business is actually worth today and identify the gaps between where you are and where you need to be." },
    { num: "02", name: "Protect", desc: "You identify and address the risks that could destroy your business value before you ever get to market." },
    { num: "03", name: "Build", desc: "You implement the systems, processes, and recurring revenue streams that make your business more valuable and less dependent on you." },
    { num: "04", name: "Harvest", desc: "You understand your exit options, identify your ideal buyer, and prepare for a successful transition." },
    { num: "05", name: "Manage", desc: "You protect and sustain the wealth your business generates — for yourself, your family, and your legacy." },
  ];
  return (
    <section aria-labelledby="solution-heading" style={{ background: "oklch(0.22 0.07 155)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up">
          <p style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 400, fontSize: "0.72rem",
            letterSpacing: "0.18em", textTransform: "uppercase", color: "oklch(0.65 0.10 75)",
            marginBottom: "0.75rem",
          }}>The NorthStar Value Path</p>
          <div style={{ width: "40px", height: "2px", background: "oklch(0.65 0.10 75)", marginBottom: "1.5rem" }} />
          <h2 id="solution-heading" style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", lineHeight: 1.15,
            color: "oklch(0.97 0.005 65)", marginBottom: "1rem", maxWidth: "640px",
          }}>
            A Proven Path from Owner-Dependent to Buyer-Ready
          </h2>
          <p style={{ color: "oklch(0.78 0.01 65)", lineHeight: 1.75, marginBottom: "3rem", maxWidth: "600px", fontSize: "1rem" }}>
            The Growth and Exit Roundtable is built on the NorthStar Value Path — a five-stage framework that takes business owners from where they are today to a business that commands a premium valuation, runs without them, and is ready to sell when they are.
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1.5rem" }}>
            {stages.map((s) => (
              <div key={s.num} style={{
                borderTop: "3px solid oklch(0.65 0.10 75)", paddingTop: "1.25rem",
              }}>
                <span style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "2rem", color: "oklch(0.65 0.10 75 / 0.35)", display: "block", lineHeight: 1, marginBottom: "0.25rem" }}>{s.num}</span>
                <span style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "1.1rem", color: "oklch(0.97 0.005 65)", display: "block", marginBottom: "0.6rem", letterSpacing: "0.04em" }}>{s.name}</span>
                <p style={{ color: "oklch(0.72 0.01 65)", fontSize: "0.88rem", lineHeight: 1.65 }}>{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Modules ──────────────────────────────────────────────────────────────────
function Modules() {
  const ref = useFadeUp();
  const modules = [
    {
      num: "01",
      title: "The Reality Check",
      desc: "You will learn exactly how buyers calculate the value of your business, what the eight value drivers are, and how to identify the gaps between your current valuation and your potential valuation. You will leave this module knowing your real number.",
    },
    {
      num: "02",
      title: "The Future Vision",
      desc: "You will define what you actually want your post-business life to look like — and calculate the exact exit number your business needs to generate to fund it. This is the module that makes the financial strategy personal.",
    },
    {
      num: "03",
      title: "Risk and Readiness",
      desc: "You will assess the foundation of your business across four dimensions of Intangible Capital, identify the risks that could destroy your value overnight, and build a prioritized action plan for addressing them.",
    },
    {
      num: "04",
      title: "Operational Freedom",
      desc: "You will implement the systems, automations, and recurring revenue strategies that free you from the day-to-day grind — and make your business worth significantly more to a buyer.",
    },
    {
      num: "05",
      title: "The Transition Roadmap",
      desc: "You will explore every available exit option, understand the M&A process in detail, and build a personalized Transition Decision Matrix that points to the right path for your situation.",
    },
    {
      num: "06",
      title: "The Master Plan",
      desc: "You will bring everything together into a single, integrated Master Plan — your roadmap for the next three to five years, reviewed and validated by your advisory team.",
    },
  ];
  return (
    <section id="modules" aria-labelledby="modules-heading" style={{ background: "oklch(0.97 0.005 65)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up">
          <p style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 400, fontSize: "0.72rem",
            letterSpacing: "0.18em", textTransform: "uppercase", color: "oklch(0.45 0.08 155)",
            marginBottom: "0.75rem",
          }}>The Curriculum</p>
          <div style={{ width: "40px", height: "2px", background: "oklch(0.65 0.10 75)", marginBottom: "1.5rem" }} />
          <h2 id="modules-heading" style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", lineHeight: 1.15,
            color: "oklch(0.22 0.07 155)", marginBottom: "0.75rem",
          }}>
            What You Get in the Growth and Exit Roundtable
          </h2>
          <p style={{ color: "oklch(0.45 0.08 155)", fontFamily: "'Oswald', sans-serif", fontWeight: 500, fontSize: "1rem", letterSpacing: "0.04em", marginBottom: "3rem" }}>
            Six Modules. Six Transformations.
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "2rem" }}>
            {modules.map((m) => (
              <div key={m.num} style={{
                background: "oklch(1 0 0)", padding: "2rem",
                borderTop: "3px solid oklch(0.65 0.10 75)",
                boxShadow: "0 2px 16px oklch(0 0 0 / 0.06)",
              }}>
                <span style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "2.2rem", color: "oklch(0.65 0.10 75 / 0.3)", display: "block", lineHeight: 1, marginBottom: "0.5rem" }}>{m.num}</span>
                <h3 style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "1.15rem", color: "oklch(0.22 0.07 155)", marginBottom: "0.75rem", letterSpacing: "0.02em" }}>
                  Module {m.num} — {m.title}
                </h3>
                <p style={{ color: "oklch(0.38 0.02 65)", fontSize: "0.92rem", lineHeight: 1.7 }}>{m.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── How It Works ─────────────────────────────────────────────────────────────
function HowItWorks() {
  const ref = useFadeUp();
  const methods = [
    {
      icon: "▶",
      title: "Video Lessons",
      desc: "Short, professionally produced video lessons for each module. No talking heads. No slides. Cinematic visuals and a clear, authoritative voiceover that respects your time and your intelligence.",
    },
    {
      icon: "◈",
      title: "AI-Powered Tools",
      desc: "Each lesson includes a custom AI tool that takes your specific inputs — your financials, your goals, your risks — and generates a personalized output. A valuation estimate. A future vision profile. A risk checklist. A scenario model.",
    },
    {
      icon: "◎",
      title: "Live Roundtable Sessions",
      desc: "At the end of each module, you bring your completed workbook to a live session with your advisory team. This is where the numbers become a real plan and your specific situation is addressed by qualified advisors.",
    },
  ];
  return (
    <section id="how" aria-labelledby="how-heading" style={{ background: "oklch(0.16 0.06 155)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up">
          <p style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 400, fontSize: "0.72rem",
            letterSpacing: "0.18em", textTransform: "uppercase", color: "oklch(0.65 0.10 75)",
            marginBottom: "0.75rem",
          }}>The Experience</p>
          <div style={{ width: "40px", height: "2px", background: "oklch(0.65 0.10 75)", marginBottom: "1.5rem" }} />
          <h2 id="how-heading" style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", lineHeight: 1.15,
            color: "oklch(0.97 0.005 65)", marginBottom: "3rem", maxWidth: "560px",
          }}>
            Three Ways You Learn. One Integrated Experience.
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: "2rem" }}>
            {methods.map((m) => (
              <div key={m.title} style={{ borderTop: "2px solid oklch(0.65 0.10 75 / 0.35)", paddingTop: "1.5rem" }}>
                <span style={{ fontSize: "1.5rem", color: "oklch(0.65 0.10 75)", display: "block", marginBottom: "0.75rem" }}>{m.icon}</span>
                <h3 style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "1.15rem", color: "oklch(0.97 0.005 65)", marginBottom: "0.75rem", letterSpacing: "0.03em" }}>{m.title}</h3>
                <p style={{ color: "oklch(0.72 0.01 65)", fontSize: "0.92rem", lineHeight: 1.7 }}>{m.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Outcomes ─────────────────────────────────────────────────────────────────
function Outcomes() {
  const ref = useFadeUp();
  const outcomes = [
    "The real current value of your business — calculated, not guessed",
    "A specific, personalized target exit number tied to your life goals",
    "A complete estate plan and legacy strategy",
    "A prioritized risk mitigation plan",
    "At least one core business process documented and running without you",
    "A clear picture of your ideal exit path and ideal buyer",
    "A complete Master Plan integrating your business strategy and personal financial future",
    "Access to the NorthStar Course Companion — an AI tool trained on the full program for ongoing support",
  ];
  return (
    <section aria-labelledby="outcomes-heading" style={{ background: "oklch(0.97 0.005 65)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "3rem", alignItems: "start" }}>
          <div style={{ maxWidth: "480px" }}>
            <p style={{
              fontFamily: "'Oswald', sans-serif", fontWeight: 400, fontSize: "0.72rem",
              letterSpacing: "0.18em", textTransform: "uppercase", color: "oklch(0.45 0.08 155)",
              marginBottom: "0.75rem",
            }}>What You Walk Away With</p>
            <div style={{ width: "40px", height: "2px", background: "oklch(0.65 0.10 75)", marginBottom: "1.5rem" }} />
            <h2 id="outcomes-heading" style={{
              fontFamily: "'Oswald', sans-serif", fontWeight: 700,
              fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", lineHeight: 1.15,
              color: "oklch(0.22 0.07 155)", marginBottom: "1.25rem",
            }}>
              By the End of the Program, You Will Have:
            </h2>
            <p style={{ color: "oklch(0.38 0.02 65)", lineHeight: 1.75, fontSize: "0.97rem" }}>
              Every deliverable is yours to keep. Every tool is built for your specific business. This is not a course you take and forget — it is a plan you execute.
            </p>
          </div>
          <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "0.85rem" }}>
            {outcomes.map((o) => (
              <li key={o} style={{
                display: "flex", gap: "0.85rem", alignItems: "flex-start",
                color: "oklch(0.35 0.02 65)", fontSize: "0.97rem", lineHeight: 1.65,
                borderBottom: "1px solid oklch(0 0 0 / 0.06)", paddingBottom: "0.85rem",
              }}>
                <span style={{ color: "oklch(0.65 0.10 75)", marginTop: "0.2rem", flexShrink: 0, fontWeight: 700, fontSize: "1rem" }}>✦</span>
                {o}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

// ─── Investment ───────────────────────────────────────────────────────────────
function Investment() {
  const ref = useFadeUp();
  const includes = [
    "Six modules of video lessons",
    "Six module workbooks with guided assignments",
    "Access to all AI-powered tools",
    "Live roundtable sessions with your advisory team",
    "The NorthStar Course Companion App",
    "Lifetime access to the course materials",
  ];
  return (
    <section id="investment" aria-labelledby="investment-heading" style={{ background: "oklch(0.22 0.07 155)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "4rem", alignItems: "center" }}>
          <div>
            <p style={{
              fontFamily: "'Oswald', sans-serif", fontWeight: 400, fontSize: "0.72rem",
              letterSpacing: "0.18em", textTransform: "uppercase", color: "oklch(0.65 0.10 75)",
              marginBottom: "0.75rem",
            }}>Enrollment</p>
            <div style={{ width: "40px", height: "2px", background: "oklch(0.65 0.10 75)", marginBottom: "1.5rem" }} />
            <h2 id="investment-heading" style={{
              fontFamily: "'Oswald', sans-serif", fontWeight: 700,
              fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", lineHeight: 1.15,
              color: "oklch(0.97 0.005 65)", marginBottom: "1.5rem",
            }}>
              Your Investment
            </h2>
            <div style={{ marginBottom: "2rem" }}>
              <span style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "3.5rem", color: "oklch(0.65 0.10 75)", lineHeight: 1 }}>$997</span>
              <span style={{ color: "oklch(0.72 0.01 65)", fontSize: "0.9rem", marginLeft: "0.5rem" }}>one-time enrollment</span>
            </div>
            <ul style={{ listStyle: "none", padding: 0, margin: "0 0 2.5rem 0", display: "flex", flexDirection: "column", gap: "0.75rem" }}>
              {includes.map((item) => (
                <li key={item} style={{ display: "flex", gap: "0.75rem", alignItems: "flex-start", color: "oklch(0.78 0.01 65)", fontSize: "0.93rem", lineHeight: 1.6 }}>
                  <span style={{ color: "oklch(0.65 0.10 75)", flexShrink: 0, marginTop: "0.15rem" }}>✦</span>
                  {item}
                </li>
              ))}
            </ul>
            <a href="#enroll" style={{
              background: "oklch(0.65 0.10 75)", color: "oklch(0.16 0.06 155)",
              fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "0.85rem",
              letterSpacing: "0.1em", textTransform: "uppercase", textDecoration: "none",
              padding: "1rem 2rem", display: "inline-block", transition: "opacity 0.2s",
            }}
              onMouseEnter={e => (e.currentTarget.style.opacity = "0.85")}
              onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
            >
              Enroll in the Growth and Exit Roundtable
            </a>
            <p style={{ color: "oklch(0.60 0.01 65)", fontSize: "0.82rem", marginTop: "0.75rem" }}>
              Not sure if you are ready? <a href="/snapshot" style={{ color: "oklch(0.65 0.10 75)", textDecoration: "underline" }}>Take the free Exit Readiness Snapshot first.</a>
            </p>
          </div>
          <div style={{ background: "oklch(0.16 0.06 155)", padding: "2.5rem" }}>
            <h3 style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "1.15rem", color: "oklch(0.65 0.10 75)", marginBottom: "1.5rem", letterSpacing: "0.06em", textTransform: "uppercase" }}>
              30-Day Satisfaction Guarantee
            </h3>
            <p style={{ color: "oklch(0.78 0.01 65)", fontSize: "0.93rem", lineHeight: 1.75, marginBottom: "1.5rem" }}>
              We stand behind the quality of this program. If you complete the first module and do not feel the program is right for you, contact us within 30 days for a full refund.
            </p>
            <div style={{ borderTop: "1px solid oklch(1 0 0 / 0.1)", paddingTop: "1.5rem" }}>
              <h3 style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "1.15rem", color: "oklch(0.65 0.10 75)", marginBottom: "1rem", letterSpacing: "0.06em", textTransform: "uppercase" }}>
                Built on Real-World Experience
              </h3>
              <p style={{ color: "oklch(0.72 0.01 65)", fontSize: "0.9rem", lineHeight: 1.7 }}>
                Developed by the team at NorthStar Value Group — exit planning advisors who have worked with hundreds of business owners across industries. This is not theory. It is the same process used with private clients, structured into a program any business owner can access.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Who It's For ─────────────────────────────────────────────────────────────
function WhoFor() {
  const ref = useFadeUp();
  const forList = [
    "You own a business generating up to $10 million in annual revenue",
    "You are thinking about selling in the next three to five years — or you want to build a business that could sell at a premium when you are ready",
    "You want to get more time back from your business right now, not just at exit",
    "You have never had a clear, structured plan for building and protecting your business value",
    "You are ready to do the work — not just learn about it",
  ];
  const notFor = [
    "You are looking for a quick fix or a shortcut",
    "You are not willing to complete the workbook assignments and attend the roundtable sessions",
    "You have already sold your business",
  ];
  return (
    <section aria-labelledby="whofor-heading" style={{ background: "oklch(0.97 0.005 65)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up">
          <p style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 400, fontSize: "0.72rem",
            letterSpacing: "0.18em", textTransform: "uppercase", color: "oklch(0.45 0.08 155)",
            marginBottom: "0.75rem",
          }}>Fit</p>
          <div style={{ width: "40px", height: "2px", background: "oklch(0.65 0.10 75)", marginBottom: "1.5rem" }} />
          <h2 id="whofor-heading" style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", lineHeight: 1.15,
            color: "oklch(0.22 0.07 155)", marginBottom: "3rem",
          }}>
            This Program Is Right for You If:
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "3rem" }}>
            <div>
              <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "0.85rem" }}>
                {forList.map((item) => (
                  <li key={item} style={{ display: "flex", gap: "0.85rem", alignItems: "flex-start", color: "oklch(0.35 0.02 65)", fontSize: "0.97rem", lineHeight: 1.65 }}>
                    <span style={{ color: "oklch(0.45 0.12 155)", marginTop: "0.2rem", flexShrink: 0, fontWeight: 700 }}>✓</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div style={{ background: "oklch(0.22 0.07 155)", padding: "2rem" }}>
              <h3 style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "1rem", color: "oklch(0.65 0.10 75)", marginBottom: "1.25rem", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                This Program Is Not For You If:
              </h3>
              <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "0.75rem" }}>
                {notFor.map((item) => (
                  <li key={item} style={{ display: "flex", gap: "0.75rem", alignItems: "flex-start", color: "oklch(0.72 0.01 65)", fontSize: "0.93rem", lineHeight: 1.65 }}>
                    <span style={{ color: "oklch(0.55 0.15 25)", flexShrink: 0, fontWeight: 700 }}>✗</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── FAQ ──────────────────────────────────────────────────────────────────────
function FAQ() {
  const ref = useFadeUp();
  const [open, setOpen] = useState<number | null>(null);
  const faqs = [
    { q: "How long does the program take to complete?", a: "Most owners complete one module every two to three weeks, making the full program a four to six month experience. You move at your own pace." },
    { q: "Do I need to have an exit planned to join?", a: "No. Many owners join the program years before they plan to exit — because the work of building a buyer-ready business is the same as the work of building a better business. The sooner you start, the more value you create." },
    { q: "What kind of business is this designed for?", a: "The program is designed for privately held businesses generating up to $10 million in annual revenue across any industry. The frameworks and tools are applicable regardless of your sector." },
    { q: "What are the live roundtable sessions?", a: "Each module concludes with a live Zoom session where you bring your completed workbook and meet with a team of qualified advisors — including an M&A advisor, exit planning attorney, CPA, financial advisor, and business coach. These sessions are where the learning becomes a personalized plan." },
    { q: "What if I have questions between sessions?", a: "The NorthStar Course Companion App — included with the program — is an AI tool trained on the full curriculum. You can ask it questions about any concept in the program, retrieve frameworks, and get customized action plans between sessions." },
    { q: "Is there a guarantee?", a: "We stand behind the quality of this program. If you complete the first module and do not feel the program is right for you, contact us within 30 days for a full refund." },
  ];
  return (
    <section id="faq" aria-labelledby="faq-heading" style={{ background: "oklch(0.16 0.06 155)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up" style={{ maxWidth: "760px", margin: "0 auto" }}>
          <p style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 400, fontSize: "0.72rem",
            letterSpacing: "0.18em", textTransform: "uppercase", color: "oklch(0.65 0.10 75)",
            marginBottom: "0.75rem",
          }}>Common Questions</p>
          <div style={{ width: "40px", height: "2px", background: "oklch(0.65 0.10 75)", marginBottom: "1.5rem" }} />
          <h2 id="faq-heading" style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", lineHeight: 1.15,
            color: "oklch(0.97 0.005 65)", marginBottom: "3rem",
          }}>
            Frequently Asked Questions
          </h2>
          <div style={{ display: "flex", flexDirection: "column", gap: "0" }}>
            {faqs.map((faq, i) => (
              <div key={i} style={{ borderTop: "1px solid oklch(1 0 0 / 0.1)" }}>
                <button
                  onClick={() => setOpen(open === i ? null : i)}
                  aria-expanded={open === i}
                  style={{
                    width: "100%", textAlign: "left", background: "none", border: "none",
                    padding: "1.25rem 0", cursor: "pointer",
                    display: "flex", justifyContent: "space-between", alignItems: "center", gap: "1rem",
                  }}
                >
                  <span style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "1rem", color: "oklch(0.92 0.005 65)", letterSpacing: "0.02em" }}>{faq.q}</span>
                  <span style={{ color: "oklch(0.65 0.10 75)", fontSize: "1.2rem", flexShrink: 0, transition: "transform 0.2s", transform: open === i ? "rotate(45deg)" : "rotate(0deg)" }}>+</span>
                </button>
                {open === i && (
                  <p style={{ color: "oklch(0.72 0.01 65)", fontSize: "0.93rem", lineHeight: 1.75, paddingBottom: "1.25rem", paddingRight: "2rem" }}>{faq.a}</p>
                )}
              </div>
            ))}
            <div style={{ borderTop: "1px solid oklch(1 0 0 / 0.1)" }} />
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Final CTA ────────────────────────────────────────────────────────────────
function FinalCTA() {
  const ref = useFadeUp();
  return (
    <section id="enroll" aria-label="Enrollment call to action" style={{ background: "oklch(0.65 0.10 75)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up" style={{ maxWidth: "680px", margin: "0 auto", textAlign: "center" }}>
          <h2 style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)", lineHeight: 1.12,
            color: "oklch(0.16 0.06 155)", marginBottom: "1.25rem",
          }}>
            Your Business Is Worth More Than You Think. Let's Prove It.
          </h2>
          <p style={{ color: "oklch(0.22 0.07 155)", lineHeight: 1.75, marginBottom: "0.75rem", fontSize: "1rem" }}>
            The owners who exit successfully are not the ones who had the best businesses. They are the ones who prepared.
          </p>
          <p style={{ color: "oklch(0.22 0.07 155)", lineHeight: 1.75, marginBottom: "0.75rem", fontSize: "1rem" }}>
            They knew their number. They protected their value. They built a business that a buyer would compete to acquire.
          </p>
          <p style={{ color: "oklch(0.22 0.07 155)", lineHeight: 1.75, marginBottom: "2.5rem", fontSize: "1rem" }}>
            That is what the Growth and Exit Roundtable is designed to help you do.
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: "1rem", alignItems: "center" }}>
            <a href="#enroll" style={{
              background: "oklch(0.22 0.07 155)", color: "oklch(0.97 0.005 65)",
              fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "0.85rem",
              letterSpacing: "0.12em", textTransform: "uppercase", textDecoration: "none",
              padding: "1rem 2.5rem", display: "inline-block", transition: "opacity 0.2s",
            }}
              onMouseEnter={e => (e.currentTarget.style.opacity = "0.85")}
              onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
            >
              Enroll Now
            </a>
            <a href="/snapshot" style={{
              color: "oklch(0.22 0.07 155)", fontFamily: "'Oswald', sans-serif",
              fontWeight: 500, fontSize: "0.78rem", letterSpacing: "0.1em",
              textTransform: "uppercase", textDecoration: "none",
              borderBottom: "1px solid oklch(0.22 0.07 155 / 0.5)", paddingBottom: "2px",
            }}>
              Take the Free Exit Readiness Snapshot First
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer role="contentinfo" style={{ background: "oklch(0.16 0.06 155)", borderTop: "1px solid oklch(1 0 0 / 0.08)" }}>
      <div className="container py-12">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "2.5rem", marginBottom: "3rem" }}>
          <div>
            <img src={BOP_LOGO} alt="Business Owner Platform" style={{ height: "40px", width: "auto", marginBottom: "0.75rem" }} />
            <p style={{ color: "oklch(0.60 0.01 65)", fontSize: "0.82rem", lineHeight: 1.65 }}>
              A platform of NorthStar Value Group. Helping business owners build, protect, and harvest the value of their businesses.
            </p>
          </div>
          <div>
            <p style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "0.72rem", letterSpacing: "0.12em", textTransform: "uppercase", color: "oklch(0.65 0.10 75)", marginBottom: "1rem" }}>The Program</p>
            {[["The Problem", "#program"], ["The NorthStar Value Path", "#program"], ["Six Modules", "#modules"], ["How It Works", "#how"], ["Investment", "#investment"], ["FAQ", "#faq"]].map(([label, href]) => (
              <a key={label} href={href} style={{ display: "block", color: "oklch(0.65 0.01 65)", fontSize: "0.85rem", lineHeight: 2, textDecoration: "none", transition: "color 0.2s" }}
                onMouseEnter={e => (e.currentTarget.style.color = "oklch(0.65 0.10 75)")}
                onMouseLeave={e => (e.currentTarget.style.color = "oklch(0.65 0.01 65)")}
              >{label}</a>
            ))}
          </div>
          <div>
            <p style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "0.72rem", letterSpacing: "0.12em", textTransform: "uppercase", color: "oklch(0.65 0.10 75)", marginBottom: "1rem" }}>Get Started</p>
            {[["Free Exit Readiness Snapshot", "/snapshot"], ["Enroll Now", "#enroll"], ["Business Owner Platform", "/"], ["About Us", "/about"]].map(([label, href]) => (
              <a key={label} href={href} style={{ display: "block", color: "oklch(0.65 0.01 65)", fontSize: "0.85rem", lineHeight: 2, textDecoration: "none", transition: "color 0.2s" }}
                onMouseEnter={e => (e.currentTarget.style.color = "oklch(0.65 0.10 75)")}
                onMouseLeave={e => (e.currentTarget.style.color = "oklch(0.65 0.01 65)")}
              >{label}</a>
            ))}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "1rem", justifyContent: "flex-end" }}>
            <div>
              <p style={{ color: "oklch(0.55 0.01 65)", fontSize: "0.75rem", marginBottom: "0.5rem" }}>Presented by</p>
              <img src={NVG_LOGO} alt="NorthStar Value Group" style={{ height: "36px", width: "auto", opacity: 0.7 }} />
            </div>
          </div>
        </div>
        <div style={{ borderTop: "1px solid oklch(1 0 0 / 0.08)", paddingTop: "1.5rem", display: "flex", flexWrap: "wrap", justifyContent: "space-between", gap: "1rem", alignItems: "center" }}>
          <p style={{ color: "oklch(0.50 0.01 65)", fontSize: "0.78rem" }}>
            &copy; {year} NorthStar Value Group. All rights reserved.
          </p>
          <div style={{ display: "flex", gap: "1.5rem" }}>
            {[["Privacy Policy", "#"], ["Terms of Use", "#"]].map(([label, href]) => (
              <a key={label} href={href} style={{ color: "oklch(0.50 0.01 65)", fontSize: "0.78rem", textDecoration: "none" }}>{label}</a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─── Schema ───────────────────────────────────────────────────────────────────
function SchemaMarkup() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "Course",
    "name": "Growth and Exit Roundtable",
    "description": "A structured six-module program for business owners who want to increase the value of their business, reduce their dependence on it, and prepare for a successful exit.",
    "provider": {
      "@type": "Organization",
      "name": "NorthStar Value Group",
      "url": "https://businessownerplatform.com"
    },
    "offers": {
      "@type": "Offer",
      "price": "997",
      "priceCurrency": "USD",
      "availability": "https://schema.org/InStock"
    },
    "numberOfCredits": 6,
    "educationalLevel": "Business Owner",
    "teaches": ["Business Valuation", "Exit Planning", "Operational Independence", "Value Driver Optimization", "M&A Process", "Business Transition Planning"]
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function Roundtable() {
  useEffect(() => {
    document.title = "Growth and Exit Roundtable | Build a Business Worth Buying | NorthStar Value Group";
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute("content", "The Growth and Exit Roundtable is a six-module program for business owners who want to increase business value, reduce owner dependence, and exit on their terms. Enroll for $997.");
  }, []);
  return (
    <>
      <SchemaMarkup />
      <a href="#main-content" style={{
        position: "absolute", left: "-9999px", top: "auto", width: "1px", height: "1px", overflow: "hidden",
        zIndex: 9999, background: "oklch(0.65 0.10 75)", color: "oklch(0.16 0.06 155)",
        padding: "0.5rem 1rem", fontFamily: "'Oswald', sans-serif",
      }}
        onFocus={e => { e.currentTarget.style.left = "0"; e.currentTarget.style.width = "auto"; e.currentTarget.style.height = "auto"; }}
        onBlur={e => { e.currentTarget.style.left = "-9999px"; e.currentTarget.style.width = "1px"; e.currentTarget.style.height = "1px"; }}
      >Skip to main content</a>
      <Nav />
      <main id="main-content">
        <Hero />
        <Problem />
        <Solution />
        <Modules />
        <HowItWorks />
        <Outcomes />
        <Investment />
        <WhoFor />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
