/**
 * Business Owner Platform — Exit Readiness Snapshot Page
 * Design: Institutional Authority (matches site-wide design)
 * Colors: Value Green #1A3D2E | Gold #B8922E | Cream #FAF7F2
 * Brief: GrowthandExitRoundtableWebsiteContentBrief.md — PAGE 2
 * Rules: No em dashes, second person, 3-sentence max paragraphs
 */

import { useEffect, useRef, useState } from "react";

const BOP_LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/AAhEwqRgJGZhnRtZwJrWVS/bop_logo_baa7a023.png";
const NVG_LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/AAhEwqRgJGZhnRtZwJrWVS/nvg_logo_7a591d90.png";
const GER_LOGO = "/manus-storage/growth_exit_roundtable_logo_8b6c2ceb.png";
const ERS_LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/AAhEwqRgJGZhnRtZwJrWVS/exit_readiness_snapshot_logo-S3eZpRxYr3p3UfVyDNCjgo.png";

function useFadeUp() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { el.classList.add("visible"); obs.disconnect(); } },
      { threshold: 0.1 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return ref;
}

// ─── Nav ──────────────────────────────────────────────────────────────────────
function Nav() {
  const [open, setOpen] = useState(false);
  const navLinks = [
    { label: "Home", href: "/" },
    { label: "The Roundtable", href: "/roundtable" },
    { label: "About Us", href: "/about" },
  ];
  return (
    <nav className="site-nav" role="navigation" aria-label="Main navigation" style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 1000,
      background: "oklch(0.16 0.06 155 / 0.97)",
      backdropFilter: "blur(8px)",
      borderBottom: "1px solid oklch(1 0 0 / 0.08)",
      height: "64px", display: "flex", alignItems: "center",
    }}>
      <div className="container" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: "100%" }}>
        <a href="/" aria-label="Business Owner Platform — Home" style={{ display: "flex", alignItems: "center", gap: "0.75rem", textDecoration: "none" }}>
          <img src={BOP_LOGO} alt="Business Owner Platform" style={{ height: "40px", width: "auto" }} />
        </a>
        <div className="hidden lg:flex" style={{ gap: "2rem", alignItems: "center" }}>
          {navLinks.map(({ label, href }) => (
            <a key={label} href={href} style={{
              color: "oklch(0.85 0.01 65)", fontSize: "0.72rem", fontFamily: "'Oswald', sans-serif",
              fontWeight: 500, letterSpacing: "0.1em", textTransform: "uppercase", textDecoration: "none",
              transition: "color 0.2s",
            }}
              onMouseEnter={e => (e.currentTarget.style.color = "oklch(0.65 0.10 75)")}
              onMouseLeave={e => (e.currentTarget.style.color = "oklch(0.85 0.01 65)")}
            >{label}</a>
          ))}
        </div>
        <div style={{ display: "flex", gap: "0.75rem", alignItems: "center" }}>
          <a href="/roundtable" className="hidden lg:inline-flex" style={{
            background: "oklch(0.65 0.10 75)", color: "oklch(0.16 0.06 155)",
            fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "0.72rem",
            letterSpacing: "0.1em", textTransform: "uppercase", textDecoration: "none",
            padding: "0.6rem 1.25rem", transition: "opacity 0.2s",
          }}
            onMouseEnter={e => (e.currentTarget.style.opacity = "0.85")}
            onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
          >
            Enroll Now
          </a>
          <button
            className="lg:hidden"
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen(!open)}
            style={{ background: "none", border: "none", cursor: "pointer", padding: "0.5rem", display: "flex", flexDirection: "column", gap: "5px" }}
          >
            {[0, 1, 2].map(i => (
              <span key={i} style={{ display: "block", width: "22px", height: "2px", background: "oklch(0.85 0.01 65)" }} />
            ))}
          </button>
        </div>
      </div>
      {open && (
        <div style={{
          position: "absolute", top: "64px", left: 0, right: 0,
          background: "oklch(0.16 0.06 155)", padding: "1.5rem",
          borderBottom: "1px solid oklch(1 0 0 / 0.08)", display: "flex", flexDirection: "column", gap: "1rem",
        }}>
          {navLinks.map(({ label, href }) => (
            <a key={label} href={href} onClick={() => setOpen(false)} style={{
              color: "oklch(0.85 0.01 65)", fontSize: "0.85rem", fontFamily: "'Oswald', sans-serif",
              fontWeight: 500, letterSpacing: "0.1em", textTransform: "uppercase", textDecoration: "none",
            }}>{label}</a>
          ))}
          <a href="/roundtable" onClick={() => setOpen(false)} style={{
            background: "oklch(0.65 0.10 75)", color: "oklch(0.16 0.06 155)",
            fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "0.8rem",
            letterSpacing: "0.1em", textTransform: "uppercase", textDecoration: "none",
            padding: "0.75rem 1.5rem", textAlign: "center", marginTop: "0.5rem",
          }}>Enroll Now</a>
        </div>
      )}
    </nav>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────────────────
function Hero() {
  return (
    <section aria-labelledby="snapshot-hero-heading" style={{
      background: "oklch(0.16 0.06 155)",
      paddingTop: "120px", paddingBottom: "80px",
      position: "relative", overflow: "hidden",
    }}>
      <div style={{
        position: "absolute", inset: 0,
        background: "radial-gradient(ellipse at 30% 60%, oklch(0.24 0.07 155 / 0.5) 0%, transparent 65%)",
        pointerEvents: "none",
      }} />
      <div className="container" style={{ position: "relative" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: "3rem", alignItems: "center", maxWidth: "900px", margin: "0 auto", textAlign: "center" }}>
          <div>
            {/* Exit Readiness Snapshot Logo */}
            <div style={{ marginBottom: "2rem", display: "flex", justifyContent: "center" }}>
              <img
                src={ERS_LOGO}
                alt="Exit Readiness Snapshot — A NorthStar Value Group Tool"
                style={{ width: "100%", maxWidth: "340px", height: "auto" }}
              />
            </div>
            <h1 id="snapshot-hero-heading" style={{
              fontFamily: "'Oswald', sans-serif", fontWeight: 700,
              fontSize: "clamp(2.2rem, 5vw, 3.8rem)", lineHeight: 1.08,
              color: "oklch(0.97 0.005 65)", marginBottom: "1.5rem",
            }}>
              Where Does Your Business<br />
              <span style={{ color: "oklch(0.65 0.10 75)" }}>Stand Right Now?</span>
            </h1>
            <p style={{
              color: "oklch(0.78 0.01 65)", fontSize: "clamp(1rem, 1.5vw, 1.15rem)",
              lineHeight: 1.75, marginBottom: "2.5rem", maxWidth: "580px", margin: "0 auto 2.5rem",
            }}>
              Take the free Exit Readiness Snapshot — a 5-minute assessment that gives you an instant picture of your business's exit readiness across five key areas.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: "1rem", alignItems: "center" }}>
              <a href="#snapshot-form" style={{
                background: "oklch(0.65 0.10 75)", color: "oklch(0.16 0.06 155)",
                fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "0.85rem",
                letterSpacing: "0.12em", textTransform: "uppercase", textDecoration: "none",
                padding: "1rem 2.5rem", display: "inline-block", transition: "opacity 0.2s",
              }}
                onMouseEnter={e => (e.currentTarget.style.opacity = "0.85")}
                onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
              >
                Start the Free Snapshot
              </a>
              <p style={{ color: "oklch(0.60 0.01 65)", fontSize: "0.82rem" }}>
                5 minutes. 15 questions. No financials required.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── What You Will Learn ──────────────────────────────────────────────────────
function WhatYouLearn() {
  const ref = useFadeUp();
  const items = [
    "What your business is likely worth today — and what it could be worth",
    "Whether your business can run without you — and what happens if it cannot",
    "Whether you know your target exit number — and how to calculate it",
    "Which of the five most common exit risks are present in your business right now",
    "Which exit path is most likely to be right for your situation",
  ];
  return (
    <section aria-labelledby="learn-heading" style={{ background: "oklch(0.97 0.005 65)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up" style={{ maxWidth: "760px", margin: "0 auto" }}>
          <p style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 400, fontSize: "0.72rem",
            letterSpacing: "0.18em", textTransform: "uppercase", color: "oklch(0.45 0.08 155)",
            marginBottom: "0.75rem",
          }}>Your Results</p>
          <div style={{ width: "40px", height: "2px", background: "oklch(0.65 0.10 75)", marginBottom: "1.5rem" }} />
          <h2 id="learn-heading" style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", lineHeight: 1.15,
            color: "oklch(0.22 0.07 155)", marginBottom: "2.5rem",
          }}>
            In 5 Minutes, You Will Know:
          </h2>
          <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "0" }}>
            {items.map((item, i) => (
              <li key={i} style={{
                display: "flex", gap: "1rem", alignItems: "flex-start",
                color: "oklch(0.35 0.02 65)", fontSize: "1rem", lineHeight: 1.7,
                borderBottom: "1px solid oklch(0 0 0 / 0.07)", padding: "1.1rem 0",
              }}>
                <span style={{
                  background: "oklch(0.22 0.07 155)", color: "oklch(0.65 0.10 75)",
                  fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "0.8rem",
                  width: "28px", height: "28px", display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0, marginTop: "0.1rem",
                }}>
                  {String(i + 1).padStart(2, "0")}
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

// ─── Five Areas ───────────────────────────────────────────────────────────────
function FiveAreas() {
  const ref = useFadeUp();
  const areas = [
    { num: "01", title: "Business Valuation Awareness", desc: "Do you know what your business is actually worth today — and what drives that number?" },
    { num: "02", title: "Owner Independence", desc: "Can the business run without you? What happens to its value if you step away?" },
    { num: "03", title: "Financial Readiness", desc: "Do you know your target exit number — the amount your business needs to generate to fund your next chapter?" },
    { num: "04", title: "Risk Protection", desc: "Are the Five D's covered? Death, disability, divorce, disagreement, and distress are the five events that can destroy business value overnight." },
    { num: "05", title: "Exit Path Clarity", desc: "Do you know which transition option is right for your situation — sale to a third party, management buyout, family transfer, or something else?" },
  ];
  return (
    <section aria-labelledby="areas-heading" style={{ background: "oklch(0.22 0.07 155)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up">
          <p style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 400, fontSize: "0.72rem",
            letterSpacing: "0.18em", textTransform: "uppercase", color: "oklch(0.65 0.10 75)",
            marginBottom: "0.75rem",
          }}>The Assessment</p>
          <div style={{ width: "40px", height: "2px", background: "oklch(0.65 0.10 75)", marginBottom: "1.5rem" }} />
          <h2 id="areas-heading" style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", lineHeight: 1.15,
            color: "oklch(0.97 0.005 65)", marginBottom: "0.75rem",
          }}>
            Five Areas. One Clear Picture.
          </h2>
          <p style={{ color: "oklch(0.72 0.01 65)", lineHeight: 1.75, marginBottom: "3rem", maxWidth: "560px", fontSize: "1rem" }}>
            The snapshot evaluates your business across the five dimensions that matter most to buyers, advisors, and your own financial future.
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "1.5rem" }}>
            {areas.map((a) => (
              <div key={a.num} style={{
                borderTop: "3px solid oklch(0.65 0.10 75)", paddingTop: "1.25rem",
              }}>
                <span style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "2rem", color: "oklch(0.65 0.10 75 / 0.3)", display: "block", lineHeight: 1, marginBottom: "0.35rem" }}>{a.num}</span>
                <h3 style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "1rem", color: "oklch(0.97 0.005 65)", marginBottom: "0.6rem", letterSpacing: "0.03em" }}>{a.title}</h3>
                <p style={{ color: "oklch(0.70 0.01 65)", fontSize: "0.87rem", lineHeight: 1.65 }}>{a.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── How It Works ─────────────────────────────────────────────────────────────
function HowItWorks() {
  const ref = useFadeUp();
  const steps = [
    {
      num: "1",
      title: "Answer 15 Questions",
      desc: "Answer 15 questions about your business across five key areas. No financials required. No preparation needed. Just honest answers.",
    },
    {
      num: "2",
      title: "Get Your Exit Readiness Score",
      desc: "Receive a personalized score across all five areas with a brief explanation of what each score means for your business.",
    },
    {
      num: "3",
      title: "See Your Next Steps",
      desc: "Get a clear, prioritized list of the most important things to focus on based on your results.",
    },
  ];
  return (
    <section aria-labelledby="snapshot-how-heading" style={{ background: "oklch(0.97 0.005 65)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up">
          <p style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 400, fontSize: "0.72rem",
            letterSpacing: "0.18em", textTransform: "uppercase", color: "oklch(0.45 0.08 155)",
            marginBottom: "0.75rem",
          }}>How It Works</p>
          <div style={{ width: "40px", height: "2px", background: "oklch(0.65 0.10 75)", marginBottom: "1.5rem" }} />
          <h2 id="snapshot-how-heading" style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3.5vw, 2.6rem)", lineHeight: 1.15,
            color: "oklch(0.22 0.07 155)", marginBottom: "3rem",
          }}>
            Three Steps to Clarity
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: "2rem", marginBottom: "3rem" }}>
            {steps.map((s) => (
              <div key={s.num} style={{ display: "flex", gap: "1.25rem", alignItems: "flex-start" }}>
                <span style={{
                  background: "oklch(0.22 0.07 155)", color: "oklch(0.65 0.10 75)",
                  fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "1.2rem",
                  width: "44px", height: "44px", display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0,
                }}>{s.num}</span>
                <div>
                  <h3 style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "1.05rem", color: "oklch(0.22 0.07 155)", marginBottom: "0.5rem", letterSpacing: "0.02em" }}>{s.title}</h3>
                  <p style={{ color: "oklch(0.40 0.02 65)", fontSize: "0.92rem", lineHeight: 1.7 }}>{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
          <div style={{ textAlign: "center" }}>
            <a href="#snapshot-form" style={{
              background: "oklch(0.65 0.10 75)", color: "oklch(0.16 0.06 155)",
              fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "0.85rem",
              letterSpacing: "0.12em", textTransform: "uppercase", textDecoration: "none",
              padding: "1rem 2.5rem", display: "inline-block", transition: "opacity 0.2s",
            }}
              onMouseEnter={e => (e.currentTarget.style.opacity = "0.85")}
              onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
            >
              Take the Free Snapshot Now
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Snapshot Form Placeholder ────────────────────────────────────────────────
function SnapshotForm() {
  const ref = useFadeUp();
  return (
    <section id="snapshot-form" aria-labelledby="form-heading" style={{ background: "oklch(0.16 0.06 155)", padding: "6rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up" style={{ maxWidth: "640px", margin: "0 auto", textAlign: "center" }}>
          {/* ERS Logo in form section */}
          <div style={{ marginBottom: "2rem", display: "flex", justifyContent: "center" }}>
            <img
              src={ERS_LOGO}
              alt="Exit Readiness Snapshot"
              style={{ width: "100%", maxWidth: "260px", height: "auto" }}
            />
          </div>
          <h2 id="form-heading" style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.6rem, 3vw, 2.2rem)", lineHeight: 1.15,
            color: "oklch(0.97 0.005 65)", marginBottom: "1rem",
          }}>
            Take the Free Exit Readiness Snapshot
          </h2>
          <p style={{ color: "oklch(0.72 0.01 65)", lineHeight: 1.75, marginBottom: "2.5rem", fontSize: "0.97rem" }}>
            Know where you stand in 5 minutes. No preparation required. Your results are instant and personalized to your business.
          </p>
          {/* Live Exit Readiness Snapshot — iframe embed */}
          <div style={{ marginBottom: "1.5rem", width: "100%" }}>
            <iframe
              id="exit-snapshot"
              src="https://faithful-screenshot-ai.lovable.app"
              width="100%"
              height="900"
              style={{ border: "none", maxWidth: "900px", display: "block", margin: "0 auto" }}
              title="Exit Readiness Snapshot"
              loading="lazy"
            />
          </div>
          <p style={{ color: "oklch(0.55 0.01 65)", fontSize: "0.82rem", lineHeight: 1.65 }}>
            After completing the snapshot, you will have the option to learn more about the Growth and Exit Roundtable — the program designed to help you close the gaps your snapshot identifies.
          </p>
        </div>
      </div>
    </section>
  );
}

// ─── Roundtable Bridge ────────────────────────────────────────────────────────
function RoundtableBridge() {
  const ref = useFadeUp();
  return (
    <section aria-label="Growth and Exit Roundtable program" style={{ background: "oklch(0.65 0.10 75)", padding: "5rem 0" }}>
      <div className="container">
        <div ref={ref} className="fade-up" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "3rem", alignItems: "center" }}>
          <div>
            <img
              src={GER_LOGO}
              alt="Growth and Exit Roundtable — Presented by NorthStar Value Group"
              style={{ width: "100%", maxWidth: "320px", height: "auto" }}
            />
          </div>
          <div>
            <h2 style={{
              fontFamily: "'Oswald', sans-serif", fontWeight: 700,
              fontSize: "clamp(1.6rem, 3vw, 2.2rem)", lineHeight: 1.15,
              color: "oklch(0.16 0.06 155)", marginBottom: "1rem",
            }}>
              Ready to Close the Gaps Your Snapshot Identifies?
            </h2>
            <p style={{ color: "oklch(0.22 0.07 155)", lineHeight: 1.75, marginBottom: "1rem", fontSize: "0.97rem" }}>
              The Growth and Exit Roundtable is the structured six-module program built to turn your snapshot results into a real plan.
            </p>
            <p style={{ color: "oklch(0.22 0.07 155)", lineHeight: 1.75, marginBottom: "2rem", fontSize: "0.97rem" }}>
              Six modules. Live advisory sessions. AI-powered tools. A complete Master Plan for your business and your future.
            </p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem", alignItems: "center" }}>
              <a href="/roundtable" style={{
                background: "oklch(0.22 0.07 155)", color: "oklch(0.97 0.005 65)",
                fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "0.82rem",
                letterSpacing: "0.1em", textTransform: "uppercase", textDecoration: "none",
                padding: "0.85rem 1.75rem", display: "inline-block", transition: "opacity 0.2s",
              }}
                onMouseEnter={e => (e.currentTarget.style.opacity = "0.85")}
                onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
              >
                Learn About the Program
              </a>

            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer role="contentinfo" style={{ background: "oklch(0.16 0.06 155)", borderTop: "1px solid oklch(1 0 0 / 0.08)" }}>
      <div className="container py-12">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: "2.5rem", marginBottom: "3rem" }}>
          <div>
            <img src={BOP_LOGO} alt="Business Owner Platform" style={{ height: "40px", width: "auto", marginBottom: "0.75rem" }} />
            <p style={{ color: "oklch(0.60 0.01 65)", fontSize: "0.82rem", lineHeight: 1.65 }}>
              A platform of NorthStar Value Group. Helping business owners build, protect, and harvest the value of their businesses.
            </p>
          </div>
          <div>
            <p style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "0.72rem", letterSpacing: "0.12em", textTransform: "uppercase", color: "oklch(0.65 0.10 75)", marginBottom: "1rem" }}>Navigate</p>
            {[["Business Owner Platform", "/"], ["Growth and Exit Roundtable", "/roundtable"], ["About Us", "/about"], ["Exit Readiness Snapshot", "/snapshot"]].map(([label, href]) => (
              <a key={label} href={href} style={{ display: "block", color: "oklch(0.65 0.01 65)", fontSize: "0.85rem", lineHeight: 2, textDecoration: "none", transition: "color 0.2s" }}
                onMouseEnter={e => (e.currentTarget.style.color = "oklch(0.65 0.10 75)")}
                onMouseLeave={e => (e.currentTarget.style.color = "oklch(0.65 0.01 65)")}
              >{label}</a>
            ))}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "1rem", justifyContent: "flex-end" }}>
            <div>
              <p style={{ color: "oklch(0.55 0.01 65)", fontSize: "0.75rem", marginBottom: "0.5rem" }}>Presented by</p>
              <img src={NVG_LOGO} alt="NorthStar Value Group" style={{ height: "36px", width: "auto", opacity: 0.7 }} />
            </div>
          </div>
        </div>
        <div style={{ borderTop: "1px solid oklch(1 0 0 / 0.08)", paddingTop: "1.5rem", display: "flex", flexWrap: "wrap", justifyContent: "space-between", gap: "1rem", alignItems: "center" }}>
          <p style={{ color: "oklch(0.50 0.01 65)", fontSize: "0.78rem" }}>
            &copy; {year} NorthStar Value Group. All rights reserved.
          </p>
          <div style={{ display: "flex", gap: "1.5rem" }}>
            {[["Privacy Policy", "#"], ["Terms of Use", "#"]].map(([label, href]) => (
              <a key={label} href={href} style={{ color: "oklch(0.50 0.01 65)", fontSize: "0.78rem", textDecoration: "none" }}>{label}</a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─── Schema ───────────────────────────────────────────────────────────────────
function SchemaMarkup() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Exit Readiness Snapshot — Free Business Assessment",
    "description": "Take the free Exit Readiness Snapshot — a 5-minute assessment that gives business owners an instant picture of their exit readiness across five key areas.",
    "url": "https://businessownerplatform.com/snapshot",
    "provider": {
      "@type": "Organization",
      "name": "NorthStar Value Group"
    }
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function Snapshot() {
  useEffect(() => {
    // Always start at the top of the page on load, regardless of URL hash
    window.scrollTo({ top: 0, behavior: "instant" });

    document.title = "Exit Readiness Snapshot | Free Business Assessment | NorthStar Value Group";
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute("content", "Take the free Exit Readiness Snapshot — a 5-minute assessment that gives you an instant picture of your business's exit readiness across five key areas. Know where you stand today.");

    // Handle postMessages from the embedded snapshot app
    function handleMessage(e: MessageEvent) {
      // Auto-resize iframe height on content change
      if (e.data && e.data.type === "exit-snapshot:height") {
        const frame = document.getElementById("exit-snapshot") as HTMLIFrameElement | null;
        if (frame) frame.style.height = e.data.height + "px";
      }
      // Scroll iframe into view on step change
      if (e.data?.type === "exit-snapshot:scrollTop") {
        const frame = document.getElementById("exit-snapshot") as HTMLIFrameElement | null;
        if (frame) frame.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }
    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, []);
  return (
    <>
      <SchemaMarkup />
      <a href="#main-content" style={{
        position: "absolute", left: "-9999px", top: "auto", width: "1px", height: "1px", overflow: "hidden",
        zIndex: 9999, background: "oklch(0.65 0.10 75)", color: "oklch(0.16 0.06 155)",
        padding: "0.5rem 1rem", fontFamily: "'Oswald', sans-serif",
      }}
        onFocus={e => { e.currentTarget.style.left = "0"; e.currentTarget.style.width = "auto"; e.currentTarget.style.height = "auto"; }}
        onBlur={e => { e.currentTarget.style.left = "-9999px"; e.currentTarget.style.width = "1px"; e.currentTarget.style.height = "1px"; }}
      >Skip to main content</a>
      <Nav />
      <main id="main-content">
        <Hero />
        <WhatYouLearn />
        <FiveAreas />
        <HowItWorks />
        <SnapshotForm />
        <RoundtableBridge />
      </main>
      <Footer />
    </>
  );
}
