/**
 * NorthStar Value Group — About Us Page
 * Design: Deep navy (#131e34) primary, gold (#C9AA71) accent, warm off-white (#F5F0E8) leader sections
 * Typography: Oswald (headings), Barlow (body)
 * Layout: Full-width alternating leader sections — photo left/right with bio, credential badge overlay
 */

import { useEffect } from "react";
import { Link } from "wouter";

const RAY_PHOTO =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/XEGS9UnebTmPzBQyvB3V8k/ray_croff_real_photo_d00829ef.png";
const PATRICK_PHOTO =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/XEGS9UnebTmPzBQyvB3V8k/patrick_smith_photo_d064623f.jpg";
const NVG_LOGO =
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/HoTK37SMNhGF7XJNYWpf2t/northstar_value_group_logo_73da785d.png";

export default function About() {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    document.title = "About Us | NorthStar Value Group";
  }, []);

  return (
    <div style={{ fontFamily: "'Barlow', sans-serif", background: "#131e34", minHeight: "100vh" }}>

      {/* ── NAV (reused from Home) ── */}
      <header style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
        background: "rgba(19,30,52,0.97)", backdropFilter: "blur(10px)",
        borderBottom: "1px solid rgba(201,170,113,0.15)",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "0 32px", height: 72,
      }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 10, textDecoration: "none" }}>
          <img src={NVG_LOGO} alt="NorthStar Value Group" style={{ height: 44, width: "auto" }} />
        </Link>
        <nav style={{ display: "flex", alignItems: "center", gap: 28 }}>
          <Link href="/" style={{ color: "rgba(255,255,255,0.75)", textDecoration: "none", fontSize: "0.88rem", fontWeight: 500, letterSpacing: "0.04em", textTransform: "uppercase" }}>Home</Link>
          <Link href="/about" style={{ color: "#C9AA71", textDecoration: "none", fontSize: "0.88rem", fontWeight: 500, letterSpacing: "0.04em", textTransform: "uppercase" }}>About</Link>
          <a href="/#platforms" style={{ color: "rgba(255,255,255,0.75)", textDecoration: "none", fontSize: "0.88rem", fontWeight: 500, letterSpacing: "0.04em", textTransform: "uppercase" }}>Our Platforms</a>
          <a href="/#how-it-works" style={{ color: "rgba(255,255,255,0.75)", textDecoration: "none", fontSize: "0.88rem", fontWeight: 500, letterSpacing: "0.04em", textTransform: "uppercase" }}>How It Works</a>
          <a href="/#get-a-grip" style={{ color: "rgba(255,255,255,0.75)", textDecoration: "none", fontSize: "0.88rem", fontWeight: 500, letterSpacing: "0.04em", textTransform: "uppercase" }}>Get A Grip</a>
        </nav>
        <div style={{ display: "flex", gap: 12 }}>
          <a href="/#platforms" style={{
            padding: "9px 20px", border: "1.5px solid rgba(201,170,113,0.6)", color: "#C9AA71",
            textDecoration: "none", fontSize: "0.8rem", fontWeight: 600, letterSpacing: "0.08em",
            textTransform: "uppercase", fontFamily: "'Oswald', sans-serif",
          }}>Explore Platforms</a>
          <a href="/#cta" style={{
            padding: "9px 20px", background: "#C9AA71", color: "#131e34",
            textDecoration: "none", fontSize: "0.8rem", fontWeight: 700, letterSpacing: "0.08em",
            textTransform: "uppercase", fontFamily: "'Oswald', sans-serif",
          }}>Find Your Direction</a>
        </div>
      </header>

      {/* ── HERO BANNER ── */}
      <section style={{
        paddingTop: 72,
        background: "linear-gradient(160deg, #0d1625 0%, #131e34 50%, #1a2a45 100%)",
        position: "relative", overflow: "hidden",
      }}>
        {/* Gold star watermark */}
        <div style={{
          position: "absolute", right: "-80px", top: "50%", transform: "translateY(-50%)",
          fontSize: 500, color: "rgba(201,170,113,0.04)", pointerEvents: "none",
          lineHeight: 1, userSelect: "none", fontFamily: "serif",
        }} aria-hidden="true">★</div>

        <div style={{ maxWidth: 900, margin: "0 auto", padding: "80px 32px 72px", position: "relative", zIndex: 1 }}>
          <span style={{
            display: "inline-flex", alignItems: "center", gap: 10,
            color: "#C9AA71", fontSize: "0.78rem", fontWeight: 600,
            letterSpacing: "0.16em", textTransform: "uppercase", marginBottom: 20,
          }}>
            <span style={{ width: 32, height: 1.5, background: "#C9AA71", display: "inline-block" }} />
            The People Behind the Platform
          </span>
          <h1 style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(2.6rem, 5vw, 4rem)", color: "#fff",
            lineHeight: 1.1, margin: "0 0 24px",
          }}>
            About <span style={{ color: "#C9AA71" }}>NorthStar</span><br />Value Group
          </h1>
          <div style={{ width: 56, height: 3, background: "#C9AA71", marginBottom: 28 }} />
          <p style={{
            color: "rgba(255,255,255,0.72)", fontSize: "1.12rem", lineHeight: 1.8,
            maxWidth: 680, margin: 0,
          }}>
            NorthStar Value Group was built by people who have sat on both sides of the table — as business owners, as advisors, and as operators who have built, scaled, and transitioned real companies. The mission is not theoretical. It is personal.
          </p>
        </div>
      </section>

      {/* ── FOUNDING STORY ── */}
      <section style={{ background: "#1C2B4A", padding: "80px 32px" }}>
        <div style={{ maxWidth: 860, margin: "0 auto" }}>
          <span style={{
            display: "inline-flex", alignItems: "center", gap: 10,
            color: "#C9AA71", fontSize: "0.78rem", fontWeight: 600,
            letterSpacing: "0.16em", textTransform: "uppercase", marginBottom: 20,
          }}>
            <span style={{ width: 32, height: 1.5, background: "#C9AA71", display: "inline-block" }} />
            Our Origin
          </span>
          <h2 style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3vw, 2.4rem)", color: "#fff",
            marginBottom: 32, lineHeight: 1.2,
          }}>Why NorthStar Exists</h2>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40 }}>
            <p style={{ color: "rgba(255,255,255,0.72)", fontSize: "1rem", lineHeight: 1.85, margin: 0 }}>
              Most business owners spend decades building something valuable — and then discover, too late, that the business they built cannot be sold, transitioned, or handed off without enormous loss. Not because it is a bad business. But because no one ever told them what buyers actually look for, or helped them build toward that standard while there was still time to act.
            </p>
            <p style={{ color: "rgba(255,255,255,0.72)", fontSize: "1rem", lineHeight: 1.85, margin: 0 }}>
              NorthStar Value Group exists to close that gap — by connecting relationship-driven advisors with growth-minded business owners through education, collaboration, and trust. Two platforms. One ecosystem. One mission: help owners build companies worth owning, and help advisors build practices worth having.
            </p>
          </div>

          {/* Pull quote */}
          <blockquote style={{
            margin: "48px 0 0",
            padding: "28px 36px",
            borderLeft: "4px solid #C9AA71",
            background: "rgba(201,170,113,0.07)",
          }}>
            <p style={{
              fontFamily: "'Oswald', sans-serif", fontWeight: 500,
              fontSize: "clamp(1.1rem, 2vw, 1.35rem)", color: "#C9AA71",
              lineHeight: 1.5, margin: "0 0 12px", fontStyle: "normal",
            }}>
              "The best outcomes for business owners happen when the right advisors are in the room — early, educated, and working together."
            </p>
            <cite style={{ color: "rgba(255,255,255,0.5)", fontSize: "0.85rem", fontStyle: "normal", letterSpacing: "0.06em" }}>
              — Ray Croff, Founder & CEO
            </cite>
          </blockquote>
        </div>
      </section>

      {/* ── LEADERSHIP HEADER ── */}
      <section style={{ background: "#131e34", padding: "72px 32px 0" }}>
        <div style={{ maxWidth: 900, margin: "0 auto", textAlign: "center" }}>
          <span style={{
            display: "inline-flex", alignItems: "center", gap: 10,
            color: "#C9AA71", fontSize: "0.78rem", fontWeight: 600,
            letterSpacing: "0.16em", textTransform: "uppercase", marginBottom: 16,
          }}>
            <span style={{ width: 32, height: 1.5, background: "#C9AA71", display: "inline-block" }} />
            The Leadership Team
            <span style={{ width: 32, height: 1.5, background: "#C9AA71", display: "inline-block" }} />
          </span>
          <h2 style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3vw, 2.6rem)", color: "#fff",
            marginBottom: 12,
          }}>The People Who Built This</h2>
          <div style={{ width: 56, height: 3, background: "#C9AA71", margin: "0 auto 24px" }} />
          <p style={{ color: "rgba(255,255,255,0.6)", maxWidth: 600, margin: "0 auto", fontSize: "1rem", lineHeight: 1.75 }}>
            Two practitioners with decades of real-world experience — one who built and exited businesses, one who scaled them. Together, they created the ecosystem that connects advisors and owners in a way that actually works.
          </p>
        </div>
      </section>

      {/* ── RAY CROFF — photo LEFT ── */}
      <section style={{ background: "#131e34", padding: "72px 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div className="leader-grid leader-grid--left">
            {/* Photo column */}
            <div style={{ position: "relative" }}>
              <div style={{
                position: "relative", overflow: "hidden",
                boxShadow: "0 24px 64px rgba(0,0,0,0.5)",
                border: "1px solid rgba(201,170,113,0.2)",
              }}>
                <img
                  src={RAY_PHOTO}
                  alt="Ray Croff — Founder & CEO, NorthStar Value Group"
                  style={{ width: "100%", display: "block", objectFit: "cover", aspectRatio: "4/5" }}
                  loading="lazy"
                />
                {/* Gold overlay bar at bottom of photo */}
                <div style={{
                  position: "absolute", bottom: 0, left: 0, right: 0,
                  background: "linear-gradient(transparent, rgba(19,30,52,0.95))",
                  padding: "48px 24px 24px",
                }}>
                  <p style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "1.4rem", color: "#fff", margin: "0 0 2px" }}>Ray Croff</p>
                  <p style={{ color: "#C9AA71", fontSize: "0.85rem", fontWeight: 500, margin: 0, letterSpacing: "0.04em" }}>Founder & CEO — NorthStar Value Group</p>
                </div>
              </div>
              {/* Credential badge strip */}
              <div style={{
                marginTop: 16,
                background: "rgba(201,170,113,0.08)",
                border: "1px solid rgba(201,170,113,0.2)",
                padding: "16px 20px",
                display: "flex", flexWrap: "wrap", gap: 8,
              }}>
                {["CEPA", "CVGA", "Dallas EPI Chapter President", "Best CEPAs in the U.S. (2020)"].map((cred) => (
                  <span key={cred} style={{
                    background: "rgba(201,170,113,0.12)", border: "1px solid rgba(201,170,113,0.35)",
                    color: "#C9AA71", fontSize: "0.72rem", fontWeight: 600,
                    letterSpacing: "0.06em", textTransform: "uppercase",
                    padding: "4px 10px",
                  }}>{cred}</span>
                ))}
              </div>
            </div>

            {/* Bio column */}
            <div style={{ display: "flex", flexDirection: "column", justifyContent: "center" }}>
              <span style={{
                color: "#C9AA71", fontSize: "0.75rem", fontWeight: 600,
                letterSpacing: "0.16em", textTransform: "uppercase", marginBottom: 12,
              }}>Founder & CEO</span>
              <h3 style={{
                fontFamily: "'Oswald', sans-serif", fontWeight: 700,
                fontSize: "clamp(2rem, 3vw, 2.8rem)", color: "#fff",
                margin: "0 0 8px", lineHeight: 1.1,
              }}>Ray Croff</h3>
              <p style={{ color: "rgba(201,170,113,0.7)", fontSize: "0.9rem", marginBottom: 28, letterSpacing: "0.04em" }}>
                Mobius Financial Advisors · CEPA · CVGA
              </p>
              <div style={{ width: 40, height: 2, background: "#C9AA71", marginBottom: 28 }} />

              {[
                "Ray Croff is the founder of the Trusted Advisor Collaborative and CEO of Northstar Value Group. He is a Certified Exit Planning Advisor (CEPA) and Certified Value Growth Advisor (CVGA) with over 15 years of experience working directly with business owners on value building, succession planning, and exit strategy.",
                "Ray's perspective is shaped by something most advisors lack: he has been on the other side of the table. As a former business owner who ran a company with employees, equipment, and real estate, he understands the complexity, the emotional weight, and the financial stakes of transitioning a business — not just as a concept, but as a lived experience.",
                "That firsthand knowledge led Ray to develop the Owner's Roundtable — a structured educational process for helping business owners understand and increase the value of their companies. From that foundation, he created the Get A Grip program, a 6-module roundtable series that has helped business owners across the country prepare for growth, transition, and exit.",
                "In 2020, Ray was named one of the best CEPAs in the United States and served as Dallas Chapter President of the Exit Planning Institute. He previously built and led the Advisors Edge platform, which connected advisors with business owner clients through education-first roundtables. The Trusted Advisor Collaborative is the next evolution of that work — a fully modernized, team-based platform built under Northstar Value Group.",
              ].map((para, i) => (
                <p key={i} style={{
                  color: "rgba(255,255,255,0.72)", fontSize: "0.97rem", lineHeight: 1.85,
                  marginBottom: i < 3 ? 18 : 0, marginTop: 0,
                }}>{para}</p>
              ))}

              {/* Credential detail list */}
              <div style={{ marginTop: 32, paddingTop: 28, borderTop: "1px solid rgba(201,170,113,0.15)" }}>
                <p style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "0.8rem", color: "#C9AA71", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 14 }}>Credentials & Recognition</p>
                <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 8 }}>
                  {[
                    "CEPA — Certified Exit Planning Advisor",
                    "CVGA — Certified Value Growth Advisor",
                    "Dallas EPI Chapter President",
                    "Named One of the Best CEPAs in the U.S. (2020)",
                  ].map((item) => (
                    <li key={item} style={{ display: "flex", alignItems: "flex-start", gap: 10, color: "rgba(255,255,255,0.65)", fontSize: "0.9rem" }}>
                      <span style={{ color: "#C9AA71", marginTop: 3, flexShrink: 0 }}>◆</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── DIVIDER ── */}
      <div style={{ background: "#131e34", padding: "0 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", height: 1, background: "rgba(201,170,113,0.12)" }} />
      </div>

      {/* ── PATRICK K. SMITH — photo RIGHT ── */}
      <section style={{ background: "#131e34", padding: "72px 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div className="leader-grid leader-grid--right">
            {/* Bio column */}
            <div style={{ display: "flex", flexDirection: "column", justifyContent: "center" }}>
              <span style={{
                color: "#C9AA71", fontSize: "0.75rem", fontWeight: 600,
                letterSpacing: "0.16em", textTransform: "uppercase", marginBottom: 12,
              }}>Chief Marketing Officer</span>
              <h3 style={{
                fontFamily: "'Oswald', sans-serif", fontWeight: 700,
                fontSize: "clamp(2rem, 3vw, 2.8rem)", color: "#fff",
                margin: "0 0 8px", lineHeight: 1.1,
              }}>Patrick K. Smith</h3>
              <p style={{ color: "rgba(201,170,113,0.7)", fontSize: "0.9rem", marginBottom: 28, letterSpacing: "0.04em" }}>
                Growth Architect & CMO · Relationship Marketing
              </p>
              <div style={{ width: 40, height: 2, background: "#C9AA71", marginBottom: 28 }} />

              {[
                "Patrick K. Smith is the Chief Marketing Officer for Northstar Value Group, the Trusted Advisor Collaborative, and the Business Owner Platform. As a Growth Architect and CMO, he brings over 40 years of real-world business scaling experience — from managing 100-door truck docks to building multi-state real estate firms averaging millions in annual sales.",
                "Patrick's philosophy is simple: a business should serve its owner, not the other way around. He pioneered \"Relationship Marketing\" principles in the 1990s — principles that remain the foundation of how the TAC builds trust with business owners today. He combines those time-tested frameworks with the most advanced AI-powered growth tools available, helping advisors and business owners organize their models, automate the busy work, and build companies that run independently of their daily presence.",
                "In 2013, a serious automobile accident forced Patrick to step back from his businesses. His recovery attorney recognized the power of the marketing and growth systems Patrick had built — and asked if he could replicate them for other clients. That moment became the spark for his current work: helping business owners build systems that scale without them, and creating assets valuable enough to sell.",
                "At the TAC, Patrick architects the marketing infrastructure that gives advisors a consistent, professional presence — from automated follow-up systems and content libraries to AI-powered outreach tools and the brand identity that positions every TAC team as a trusted authority in their market.",
              ].map((para, i) => (
                <p key={i} style={{
                  color: "rgba(255,255,255,0.72)", fontSize: "0.97rem", lineHeight: 1.85,
                  marginBottom: i < 3 ? 18 : 0, marginTop: 0,
                }}>{para}</p>
              ))}

              {/* Credential detail list */}
              <div style={{ marginTop: 32, paddingTop: 28, borderTop: "1px solid rgba(201,170,113,0.15)" }}>
                <p style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "0.8rem", color: "#C9AA71", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 14 }}>Expertise & Background</p>
                <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 8 }}>
                  {[
                    "Growth Architecture & Systems Design",
                    "Relationship Marketing (since the 1990s)",
                    "AI-Powered Business Automation",
                    "40+ Years of Real-World Business Scaling",
                  ].map((item) => (
                    <li key={item} style={{ display: "flex", alignItems: "flex-start", gap: 10, color: "rgba(255,255,255,0.65)", fontSize: "0.9rem" }}>
                      <span style={{ color: "#C9AA71", marginTop: 3, flexShrink: 0 }}>◆</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Photo column */}
            <div style={{ position: "relative" }}>
              <div style={{
                position: "relative", overflow: "hidden",
                boxShadow: "0 24px 64px rgba(0,0,0,0.5)",
                border: "1px solid rgba(201,170,113,0.2)",
              }}>
                <img
                  src={PATRICK_PHOTO}
                  alt="Patrick K. Smith — Chief Marketing Officer, NorthStar Value Group"
                  style={{ width: "100%", display: "block", objectFit: "cover", aspectRatio: "4/5" }}
                  loading="lazy"
                />
                <div style={{
                  position: "absolute", bottom: 0, left: 0, right: 0,
                  background: "linear-gradient(transparent, rgba(19,30,52,0.95))",
                  padding: "48px 24px 24px",
                }}>
                  <p style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "1.4rem", color: "#fff", margin: "0 0 2px" }}>Patrick K. Smith</p>
                  <p style={{ color: "#C9AA71", fontSize: "0.85rem", fontWeight: 500, margin: 0, letterSpacing: "0.04em" }}>Chief Marketing Officer — NorthStar Value Group</p>
                </div>
              </div>
              {/* Credential badge strip */}
              <div style={{
                marginTop: 16,
                background: "rgba(201,170,113,0.08)",
                border: "1px solid rgba(201,170,113,0.2)",
                padding: "16px 20px",
                display: "flex", flexWrap: "wrap", gap: 8,
              }}>
                {["Growth Architect", "CMO", "Relationship Marketing", "40+ Years Experience"].map((cred) => (
                  <span key={cred} style={{
                    background: "rgba(201,170,113,0.12)", border: "1px solid rgba(201,170,113,0.35)",
                    color: "#C9AA71", fontSize: "0.72rem", fontWeight: 600,
                    letterSpacing: "0.06em", textTransform: "uppercase",
                    padding: "4px 10px",
                  }}>{cred}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── MISSION BAND ── */}
      <section style={{
        background: "#C9AA71", padding: "56px 32px", textAlign: "center",
      }}>
        <div style={{ maxWidth: 800, margin: "0 auto" }}>
          <p style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.3rem, 2.5vw, 1.9rem)", color: "#131e34",
            lineHeight: 1.45, margin: "0 0 16px",
          }}>
            "Guiding Advisors. Empowering Owners. Creating Legacies."
          </p>
          <p style={{ color: "rgba(19,30,52,0.65)", fontSize: "0.95rem", margin: 0 }}>
            — The NorthStar Value Group Mission
          </p>
        </div>
      </section>

      {/* ── CTA ── */}
      <section style={{ background: "#1C2B4A", padding: "80px 32px", textAlign: "center" }}>
        <div style={{ maxWidth: 680, margin: "0 auto" }}>
          <h2 style={{
            fontFamily: "'Oswald', sans-serif", fontWeight: 700,
            fontSize: "clamp(1.8rem, 3vw, 2.4rem)", color: "#fff",
            marginBottom: 16,
          }}>Ready to Find Your Direction?</h2>
          <p style={{ color: "rgba(255,255,255,0.65)", fontSize: "1rem", lineHeight: 1.75, marginBottom: 36 }}>
            Whether you are an advisor looking to grow your practice or a business owner ready to build real value, your next step starts here.
          </p>
          <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
            <a href="#" style={{
              padding: "14px 32px", background: "#C9AA71", color: "#131e34",
              textDecoration: "none", fontFamily: "'Oswald', sans-serif",
              fontWeight: 700, fontSize: "0.9rem", letterSpacing: "0.1em", textTransform: "uppercase",
            }}>I'm an Advisor — Show Me TAC</a>
            <a href="#" style={{
              padding: "14px 32px", border: "2px solid rgba(201,170,113,0.6)", color: "#C9AA71",
              textDecoration: "none", fontFamily: "'Oswald', sans-serif",
              fontWeight: 700, fontSize: "0.9rem", letterSpacing: "0.1em", textTransform: "uppercase",
            }}>I'm a Business Owner — Show Me BOP</a>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer style={{
        background: "#0d1625", borderTop: "1px solid rgba(201,170,113,0.12)",
        padding: "40px 32px 24px",
      }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <img src={NVG_LOGO} alt="NorthStar Value Group" style={{ height: 36, width: "auto" }} />
          </div>
          <nav style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
            <Link href="/" style={{ color: "rgba(255,255,255,0.45)", textDecoration: "none", fontSize: "0.82rem" }}>Home</Link>
            <Link href="/about" style={{ color: "rgba(255,255,255,0.45)", textDecoration: "none", fontSize: "0.82rem" }}>About</Link>
            <a href="/#platforms" style={{ color: "rgba(255,255,255,0.45)", textDecoration: "none", fontSize: "0.82rem" }}>Platforms</a>
            <a href="/#faq" style={{ color: "rgba(255,255,255,0.45)", textDecoration: "none", fontSize: "0.82rem" }}>FAQ</a>
          </nav>
          <p style={{ color: "rgba(255,255,255,0.25)", fontSize: "0.78rem", margin: 0 }}>
            © 2026 NorthStar Value Group. All rights reserved.
          </p>
        </div>
      </footer>

      <style>{`
        /* Leader grid — alternating photo/bio layout */
        .leader-grid {
          display: grid;
          gap: 64px;
          align-items: start;
        }
        .leader-grid--left {
          grid-template-columns: 420px 1fr;
        }
        .leader-grid--right {
          grid-template-columns: 1fr 420px;
        }

        /* Mobile: stack vertically */
        @media (max-width: 900px) {
          .leader-grid--left,
          .leader-grid--right {
            grid-template-columns: 1fr;
            gap: 40px;
          }
          /* On mobile, photo always comes first */
          .leader-grid--right > div:first-child {
            order: 2;
          }
          .leader-grid--right > div:last-child {
            order: 1;
          }
        }

        /* Nav hide on small screens */
        @media (max-width: 768px) {
          header nav { display: none; }
          header > div:last-child { display: none; }
        }
      `}</style>
    </div>
  );
}
