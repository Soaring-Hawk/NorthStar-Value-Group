/**
 * NorthStar Value Group — Landing Page
 * Design: Premium dark-navy authority with gold accents
 * Fonts: Oswald (display) + Barlow (body)
 * Colors: Navy #1C2B4A | Gold #C9AA71 | Warm White #F4F1EB
 * SEO: Semantic HTML5 landmarks, aria-labels, heading hierarchy
 * Mobile: Responsive via CSS classes + media queries in index.css
 */

import { useState, useEffect } from "react";

const LOGO_NSV = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/HoTK37SMNhGF7XJNYWpf2t/northstar_value_group_logo_73da785d.png";
const LOGO_TAC = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/HoTK37SMNhGF7XJNYWpf2t/trusted_advisor_collaborative_logo_8f9534e0.png";
const LOGO_BOP = "https://d2xsxph8kpxj0f.cloudfront.net/310519663431085952/HoTK37SMNhGF7XJNYWpf2t/business_owner_platform_logo_cfa018fa.png";

export default function Home() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div style={{ fontFamily: "'Barlow', sans-serif", color: "#2D2D2D", background: "#fff" }}>

      {/* ── NAVIGATION ── */}
      <header role="banner">
        <nav aria-label="Main navigation" style={{
          position: "fixed", top: 0, left: 0, right: 0, zIndex: 1000,
          background: scrolled ? "rgba(19,30,52,0.98)" : "rgba(19,30,52,0.92)",
          backdropFilter: "blur(10px)",
          borderBottom: "1px solid rgba(201,170,113,0.18)",
          transition: "background 0.3s ease",
        }}>
          <div style={{ maxWidth: 1160, margin: "0 auto", padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 76 }}>
            <a href="#home" aria-label="NorthStar Value Group — Home">
              <img src={LOGO_NSV} alt="NorthStar Value Group logo" style={{ height: 52, width: "auto" }} loading="eager" />
            </a>
            {/* Desktop nav */}
            <ul style={{ display: "flex", gap: 32, listStyle: "none", margin: 0, padding: 0 }} className="hidden-mobile">
              {[["/about","About"],["#platforms","Our Platforms"],["#how-it-works","How It Works"],["#roundtable","Get A Grip"],["#audiences","Who We Serve"]].map(([href, label]) => (
                <li key={href}>
                  <a href={href} style={{ fontFamily: "'Barlow', sans-serif", fontWeight: 500, fontSize: "0.95rem", color: "rgba(255,255,255,0.82)", letterSpacing: "0.02em", textDecoration: "none", transition: "color 0.2s" }}
                    onMouseEnter={e => (e.currentTarget.style.color = "#C9AA71")}
                    onMouseLeave={e => (e.currentTarget.style.color = "rgba(255,255,255,0.82)")}
                  >{label}</a>
                </li>
              ))}
            </ul>
            <div style={{ display: "flex", gap: 12, alignItems: "center" }} className="hidden-mobile">
              <a href="#platforms" style={outlineBtnStyle}>Explore Platforms</a>
              <a href="#cta" style={goldBtnStyle}>Find Your Direction</a>
            </div>
            {/* Mobile hamburger */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              style={{ display: "none", flexDirection: "column", gap: 5, background: "none", border: "none", cursor: "pointer", padding: "8px 4px", minHeight: 44 }}
              className="show-mobile"
              aria-label={mobileOpen ? "Close menu" : "Open menu"}
              aria-expanded={mobileOpen}
              aria-controls="mobile-menu"
            >
              <span style={{ display: "block", width: 26, height: 2, background: "#fff", transition: "transform 0.2s", transform: mobileOpen ? "rotate(45deg) translate(5px, 5px)" : "none" }} />
              <span style={{ display: "block", width: 26, height: 2, background: "#fff", transition: "opacity 0.2s", opacity: mobileOpen ? 0 : 1 }} />
              <span style={{ display: "block", width: 26, height: 2, background: "#fff", transition: "transform 0.2s", transform: mobileOpen ? "rotate(-45deg) translate(5px, -5px)" : "none" }} />
            </button>
          </div>
          {/* Mobile menu */}
          {mobileOpen && (
            <div id="mobile-menu" role="navigation" aria-label="Mobile navigation" style={{ background: "#131e34", padding: "20px 24px 28px", borderTop: "1px solid rgba(201,170,113,0.15)" }}>
              {[["/about","About"],["#platforms","Our Platforms"],["#how-it-works","How It Works"],["#roundtable","Get A Grip"],["#audiences","Who We Serve"]].map(([href, label]) => (
                <a key={href} href={href} onClick={() => setMobileOpen(false)} style={{ display: "flex", alignItems: "center", color: "rgba(255,255,255,0.85)", fontWeight: 500, padding: "14px 0", borderBottom: "1px solid rgba(255,255,255,0.07)", textDecoration: "none", minHeight: 44 }}>{label}</a>
              ))}
              <div style={{ marginTop: 20, display: "flex", flexDirection: "column", gap: 12 }}>
                <a href="#platforms" style={{ ...outlineBtnStyle, textAlign: "center", justifyContent: "center" }}>Explore Platforms</a>
                <a href="#cta" style={{ ...goldBtnStyle, textAlign: "center", justifyContent: "center" }}>Find Your Direction</a>
              </div>
            </div>
          )}
        </nav>
      </header>

      {/* ── HERO ── */}
      <main id="main-content">
        <section id="home" aria-label="Hero — Find Your Direction" style={{
          background: "#131e34",
          backgroundImage: "radial-gradient(ellipse at 70% 50%, rgba(46,95,138,0.22) 0%, transparent 60%), radial-gradient(ellipse at 15% 80%, rgba(201,170,113,0.07) 0%, transparent 50%)",
          minHeight: "100vh", display: "flex", alignItems: "center",
          padding: "120px 24px 80px", position: "relative", overflow: "hidden",
        }}>
          <div style={{ position: "absolute", right: "4%", top: "50%", transform: "translateY(-50%)", fontSize: 480, color: "rgba(201,170,113,0.035)", pointerEvents: "none", lineHeight: 1, userSelect: "none", fontFamily: "serif" }} aria-hidden="true">★</div>
          <div className="hero-grid" style={{ maxWidth: 1160, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center", position: "relative", zIndex: 1, width: "100%" }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
                <span style={{ display: "block", width: 32, height: 1, background: "#C9AA71" }} aria-hidden="true" />
                <span style={{ fontFamily: "'Oswald', sans-serif", fontSize: "0.78rem", letterSpacing: "0.2em", textTransform: "uppercase", color: "#C9AA71" }}>The Advisor-Owner Ecosystem</span>
              </div>
              <h1 style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "clamp(2.8rem, 5vw, 4.2rem)", lineHeight: 1.08, color: "#fff", marginBottom: 24 }}>
                Find Your<br /><span style={{ color: "#C9AA71" }}>Direction.</span>
              </h1>
              <p style={{ fontSize: "1.12rem", color: "rgba(255,255,255,0.72)", marginBottom: 36, lineHeight: 1.78, fontWeight: 300, maxWidth: 520 }}>
                NorthStar Value Group unites elite advisors and growth-minded business owners in a dual-sided ecosystem built on education, collaboration, and trust — so owners can build companies worth buying, and advisors can build practices worth having.
              </p>
              <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
                <a href="#platforms" style={goldBtnStyle}>Explore Our Platforms</a>
                <a href="#roundtable" style={outlineBtnStyle}>Attend a Roundtable</a>
              </div>
              <div className="hero-stats" style={{ display: "flex", gap: 44, marginTop: 52, paddingTop: 40, borderTop: "1px solid rgba(201,170,113,0.18)", flexWrap: "wrap" }}>
                {[["1,000","Owner exits — our 5-year mission"],["80%","Of businesses never successfully sell"],["2","Platforms. One unified ecosystem."]].map(([num, label]) => (
                  <div key={num}>
                    <span style={{ fontFamily: "'Oswald', sans-serif", fontSize: "2rem", fontWeight: 700, color: "#C9AA71", display: "block", lineHeight: 1 }}>{num}</span>
                    <span style={{ fontSize: "0.82rem", color: "rgba(255,255,255,0.55)", marginTop: 6, display: "block", lineHeight: 1.5 }}>{label}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="hero-logo-panel" style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
              <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,170,113,0.2)", borderRadius: 12, padding: 40, backdropFilter: "blur(4px)" }}>
                <img src={LOGO_NSV} alt="NorthStar Value Group — Guiding Advisors. Empowering Owners." style={{ width: "100%", maxWidth: 380, borderRadius: 6 }} loading="eager" />
              </div>
            </div>
          </div>
        </section>

        {/* ── MISSION STRIP ── */}
        <div role="complementary" aria-label="Brand mission" style={{ background: "#C9AA71", padding: "26px 24px" }}>
          <div style={{ maxWidth: 1160, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "center", gap: 16, flexWrap: "wrap" }}>
            <span style={{ fontSize: "1.3rem", color: "#131e34" }} aria-hidden="true">★</span>
            <p style={{ fontFamily: "'Oswald', sans-serif", fontSize: "1.08rem", fontWeight: 600, color: "#131e34", textAlign: "center", letterSpacing: "0.04em", margin: 0 }}>
              Where Trust Becomes Legacy — Guiding Advisors. Empowering Owners. Creating Legacies.
            </p>
            <span style={{ fontSize: "1.3rem", color: "#131e34" }} aria-hidden="true">★</span>
          </div>
        </div>

        {/* ── WHO WE ARE ── */}
        <section id="about" aria-labelledby="about-heading" style={{ padding: "90px 24px", background: "#F4F1EB" }}>
          <div className="two-col-grid" style={{ maxWidth: 1160, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 70, alignItems: "center" }}>
            <div>
              <span className="section-label">Our Purpose</span>
              <h2 id="about-heading" style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "clamp(2rem, 3.5vw, 2.8rem)", color: "#1C2B4A", marginBottom: 8 }}>The Ecosystem Built on Education</h2>
              <div className="gold-divider" />
              <p style={{ color: "#444", marginBottom: 18, fontSize: "1.02rem", lineHeight: 1.78 }}>NorthStar Value Group is the parent organization uniting two powerful platforms — the <strong>Trusted Advisor Collaborative</strong> and the <strong>Business Owner Platform</strong> — under a single, purpose-driven mission.</p>
              <p style={{ color: "#444", marginBottom: 18, fontSize: "1.02rem", lineHeight: 1.78 }}>Just as the North Star has guided navigators for centuries, NorthStar Value Group provides unwavering direction for advisors who want to grow and for owners who want to exit — both on their own terms.</p>
              <p style={{ color: "#444", marginBottom: 28, fontSize: "1.02rem", lineHeight: 1.78 }}>We are not a marketing platform, a lead-generation service, or a coaching program. We are a dual-sided ecosystem that connects relationship-driven advisors with business owners who are ready to build real value — creating the conditions for trust, education, and successful exits.</p>
              <blockquote cite="https://northstarvg-hotk37sm.manus.space/" style={{ background: "#1C2B4A", borderLeft: "4px solid #C9AA71", padding: "26px 30px", borderRadius: "0 4px 4px 0", margin: 0 }}>
                <p style={{ fontStyle: "italic", fontSize: "1.05rem", color: "#F4F1EB", margin: 0, lineHeight: 1.72 }}>"We believe the best outcomes for business owners happen when the right advisors are in the room — early, educated, and working together."</p>
              </blockquote>
            </div>
            <div className="values-grid" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              {[
                ["🧭","North Star Clarity","Clear, honest guidance — even when the truth is uncomfortable. No fluff. No false promises."],
                ["🤝","Collaboration First","Advisors win together and owners thrive when surrounded by the right team."],
                ["📚","Education Before Transaction","We lead with insight, not sales. An educated advisor or owner always makes better decisions."],
                ["🔒","Earned Trust","Trust is built through consistent, accountable, education-first relationships — not transactions."],
                ["💡","Abundance Mindset","There is more than enough opportunity for everyone who shows up with integrity and generosity."],
                ["🏛️","Impact Beyond Income","The real measure of success is the legacy created for owners, families, and the advisors who serve them."],
              ].map(([icon, title, text]) => (
                <article key={title as string} style={{ background: "#fff", border: "1px solid #e8e4dc", borderRadius: 8, padding: "22px 20px", transition: "border-color 0.2s, box-shadow 0.2s" }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#C9AA71"; (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 20px rgba(201,170,113,0.15)"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#e8e4dc"; (e.currentTarget as HTMLElement).style.boxShadow = "none"; }}
                >
                  <div style={{ fontSize: "1.4rem", marginBottom: 10 }} aria-hidden="true">{icon}</div>
                  <h3 style={{ fontFamily: "'Oswald', sans-serif", fontSize: "0.95rem", fontWeight: 600, color: "#1C2B4A", marginBottom: 6 }}>{title as string}</h3>
                  <p style={{ fontSize: "0.87rem", color: "#666", lineHeight: 1.6, margin: 0 }}>{text as string}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* ── PLATFORMS ── */}
        <section id="platforms" aria-labelledby="platforms-heading" style={{ padding: "90px 24px", background: "#131e34" }}>
          <div style={{ maxWidth: 1160, margin: "0 auto" }}>
            <div style={{ textAlign: "center", marginBottom: 60 }}>
              <span className="section-label">Two Platforms. One Direction.</span>
              <h2 id="platforms-heading" style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "clamp(2rem, 3.5vw, 2.8rem)", color: "#fff", marginBottom: 8 }}>Built for Advisors. Built for Owners.</h2>
              <div className="gold-divider-center" />
              <p style={{ color: "rgba(255,255,255,0.62)", maxWidth: 620, margin: "0 auto", fontSize: "1.02rem" }}>Whether you are an advisor who wants better clients or an owner who wants a better exit — you need a North Star. These are the platforms that get you there.</p>
            </div>
            <div className="two-col-grid" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
              <PlatformCard
                logo={LOGO_TAC}
                forLabel="For Advisors"
                forColor="#DBD0BE"
                bg="linear-gradient(160deg, #7a0820 0%, #4d0514 100%)"
                border="rgba(219,208,190,0.2)"
                title="Stop Prospecting Alone. Start Winning Together."
                desc="The Trusted Advisor Collaborative is a team-based growth ecosystem for relationship-driven professionals who want to serve business owners — without the grind of cold outreach and solo prospecting."
                features={["Team-based prospecting with complementary advisors","Education-first roundtable system that builds trust before the sale","Proven outreach frameworks and content library","Get A Grip Roundtable facilitation guides and support","A community of collaborative, non-competing advisors"]}
                arrowColor="#DBD0BE"
                btnLabel="Learn About TAC"
                btnBorder="#DBD0BE"
                btnHoverBg="#DBD0BE"
                btnHoverColor="#4d0514"
              />
              <PlatformCard
                logo={LOGO_BOP}
                forLabel="For Business Owners"
                forColor="#B8922E"
                bg="linear-gradient(160deg, #1e4d35 0%, #0f2519 100%)"
                border="rgba(184,146,46,0.25)"
                title="A Business Worth Owning Is a Business Worth Buying."
                desc="The Business Owner Platform is an education-first ecosystem that helps owners build companies that run more smoothly, grow more predictably, and rely less on any one person — including the owner."
                features={["Exit Readiness Assessment — know where you actually stand","Value driver education: what buyers actually look for","Operational freedom: build a business that runs without you","Financial clarity: know your numbers, grow your value","Access to a vetted advisor network when you are ready"]}
                arrowColor="#B8922E"
                btnLabel="Learn About BOP"
                btnBorder="#B8922E"
                btnHoverBg="#B8922E"
                btnHoverColor="#0f2519"
              />
            </div>
          </div>
        </section>

        {/* ── HOW IT WORKS ── */}
        <section id="how-it-works" aria-labelledby="how-heading" style={{ padding: "90px 24px", background: "#fff" }}>
          <div style={{ maxWidth: 1160, margin: "0 auto" }}>
            <div style={{ textAlign: "center", marginBottom: 64 }}>
              <span className="section-label">The Model</span>
              <h2 id="how-heading" style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "clamp(2rem, 3.5vw, 2.8rem)", color: "#1C2B4A", marginBottom: 8 }}>How the Ecosystem Works</h2>
              <div className="gold-divider-center" />
              <p style={{ maxWidth: 600, margin: "0 auto", color: "#555", fontSize: "1.02rem" }}>Most platforms sell leads. We create relationships. Here is how the NorthStar ecosystem creates compounding value for both advisors and owners.</p>
            </div>
            <ol className="three-col-grid" style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 40, position: "relative", listStyle: "none", padding: 0, margin: 0 }}>
              <div className="connector-line" style={{ position: "absolute", top: 36, left: "calc(16.66% + 20px)", right: "calc(16.66% + 20px)", height: 2, background: "#C9AA71", zIndex: 0 }} aria-hidden="true" />
              {[
                ["01","Advisors Join the Collaborative","Relationship-driven advisors — financial planners, CPAs, attorneys, and exit professionals — join the Trusted Advisor Collaborative and form local teams with complementary disciplines."],
                ["02","Teams Host Get A Grip Roundtables","Advisor teams host educational roundtables for business owners using TAC-provided curriculum. No sales pitches — pure education on business value, exit readiness, and risk reduction."],
                ["03","Owners Build. Advisors Grow.","Owners who attend join the Business Owner Platform for ongoing education and support. Advisors build trusted relationships with qualified prospects — before their competitors even know the owner exists."],
              ].map(([num, title, text]) => (
                <li key={num} style={{ textAlign: "center", position: "relative", zIndex: 1 }}>
                  <div style={{ width: 72, height: 72, borderRadius: "50%", background: "#1C2B4A", border: "3px solid #C9AA71", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px", fontFamily: "'Oswald', sans-serif", fontSize: "1.5rem", fontWeight: 700, color: "#C9AA71" }} aria-hidden="true">{num}</div>
                  <h3 style={{ fontFamily: "'Oswald', sans-serif", fontSize: "1.12rem", fontWeight: 600, color: "#1C2B4A", marginBottom: 12 }}>{title}</h3>
                  <p style={{ fontSize: "0.95rem", color: "#555", lineHeight: 1.72, margin: 0 }}>{text}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* ── STATS BAND ── */}
        <div role="region" aria-label="Key statistics" style={{ background: "#1C2B4A", padding: "70px 24px" }}>
          <div className="four-col-grid" style={{ maxWidth: 1160, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 40, textAlign: "center" }}>
            {[["80%","of businesses that go to market never successfully sell"],["1,000","successful owner exits — our 5-year vision"],["3–5","years earlier — when owners who exit on their terms start preparing"],["2x","platforms working together to create a compounding network effect"]].map(([num, label]) => (
              <div key={num}>
                <span style={{ fontFamily: "'Oswald', sans-serif", fontSize: "clamp(2.2rem, 3.5vw, 2.8rem)", fontWeight: 700, color: "#C9AA71", display: "block", lineHeight: 1, marginBottom: 10 }}>{num}</span>
                <span style={{ fontSize: "0.92rem", color: "rgba(255,255,255,0.65)", lineHeight: 1.55 }}>{label}</span>
                <div style={{ width: 28, height: 2, background: "#C9AA71", margin: "12px auto 0", opacity: 0.45 }} aria-hidden="true" />
              </div>
            ))}
          </div>
        </div>

        {/* ── DIFFERENTIATORS ── */}
        <section aria-labelledby="diff-heading" style={{ padding: "90px 24px", background: "#F4F1EB" }}>
          <div style={{ maxWidth: 1160, margin: "0 auto" }}>
            <div style={{ textAlign: "center", marginBottom: 56 }}>
              <span className="section-label">Why NorthStar</span>
              <h2 id="diff-heading" style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "clamp(2rem, 3.5vw, 2.8rem)", color: "#1C2B4A", marginBottom: 8 }}>What Makes This Different</h2>
              <div className="gold-divider-center" />
            </div>
            <div className="three-col-grid" style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 28 }}>
              {[
                ["🎯","Dual-Sided Platform","Advisors get a built-in prospecting ecosystem. Owners get objective, education-first guidance. Both sides benefit from the same network — creating compounding value as the ecosystem grows."],
                ["📖","Education Before Transaction","We lead with insight, not sales. An educated owner makes better decisions. An advisor who teaches becomes the obvious choice when the owner is ready to move."],
                ["👥","Team-Based, Not Solo","Advisors form local teams of 3–5 professionals with complementary disciplines. They combine networks, share expertise, and show up together — creating a better experience for everyone."],
                ["🔍","No Hidden Agendas","We have no products to sell, no brokers to feed, and no commissions to chase. The platform is education-first, not transaction-first — and owners know it."],
                ["🏆","A Proven Conversion Engine","Get A Grip Roundtables create natural, permission-based follow-up conversations with qualified prospects who already trust the room."],
                ["🌍","Built Around a Mission","Our goal is 1,000 successful owner exits in five years — not vanity metrics. Every feature and event is designed to move owners and advisors closer to that outcome."],
              ].map(([icon, title, text]) => (
                <article key={title as string} style={{ background: "#fff", borderRadius: 8, padding: "34px 28px", borderTop: "4px solid #C9AA71", boxShadow: "0 2px 16px rgba(0,0,0,0.06)", transition: "box-shadow 0.2s, transform 0.2s" }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = "0 8px 32px rgba(0,0,0,0.1)"; (e.currentTarget as HTMLElement).style.transform = "translateY(-4px)"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = "0 2px 16px rgba(0,0,0,0.06)"; (e.currentTarget as HTMLElement).style.transform = "none"; }}
                >
                  <div style={{ width: 50, height: 50, background: "#1C2B4A", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 20, fontSize: "1.25rem" }} aria-hidden="true">{icon}</div>
                  <h3 style={{ fontFamily: "'Oswald', sans-serif", fontSize: "1.08rem", fontWeight: 600, color: "#1C2B4A", marginBottom: 12 }}>{title as string}</h3>
                  <p style={{ fontSize: "0.94rem", color: "#555", lineHeight: 1.72, margin: 0 }}>{text as string}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* ── GET A GRIP ROUNDTABLE ── */}
        <section id="roundtable" aria-labelledby="roundtable-heading" style={{ padding: "90px 24px", background: "#131e34", position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", left: -100, top: -100, width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle, rgba(201,170,113,0.07) 0%, transparent 70%)", pointerEvents: "none" }} aria-hidden="true" />
          <div className="two-col-grid" style={{ maxWidth: 1160, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 70, alignItems: "center", position: "relative", zIndex: 1 }}>
            <div>
              <span className="section-label">The Bridge Event</span>
              <h2 id="roundtable-heading" style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "clamp(2rem, 3.5vw, 2.8rem)", color: "#fff", marginBottom: 8 }}>Get A Grip Roundtable</h2>
              <div className="gold-divider" />
              <p style={{ color: "rgba(255,255,255,0.72)", marginBottom: 16, fontSize: "1.02rem", lineHeight: 1.78 }}>The Get A Grip Roundtable is where business owners first hear the truth — and where the right advisors are already in the room. These educational events are the primary bridge between the Business Owner Platform and the Trusted Advisor Collaborative.</p>
              <p style={{ color: "rgba(255,255,255,0.72)", marginBottom: 32, fontSize: "1.02rem", lineHeight: 1.78 }}>No sales pitches. No pressure. Just the information every business owner needs before they can make a smart decision about their future.</p>
              <a href="#cta" style={goldBtnStyle}>Register for a Roundtable</a>
            </div>
            <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,170,113,0.22)", borderRadius: 10, padding: "32px 36px" }}>
              <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: "1.05rem", fontWeight: 600, color: "#C9AA71", marginBottom: 24, letterSpacing: "0.04em" }}>What Owners Learn at Every Roundtable</div>
              <ul style={{ listStyle: "none", margin: 0, padding: 0 }}>
                {["Business valuation basics — what your business is actually worth today, and why it may be different than you think","The eight value drivers buyers care about most — and how your business scores on each one","The most common reasons businesses fail to sell — and how to make sure yours is in the other 20%","What you can do right now — specific, actionable steps to increase value and reduce risk before you need to","Access to a team of advisors who can answer financial, legal, operational, and strategic questions — with no agenda"].map((item, i) => (
                  <li key={i} style={{ display: "flex", alignItems: "flex-start", gap: 14, color: "rgba(255,255,255,0.78)", fontSize: "0.96rem", marginBottom: 18, paddingBottom: 18, borderBottom: i < 4 ? "1px solid rgba(255,255,255,0.07)" : "none", lineHeight: 1.6 }}>
                    <span style={{ width: 22, height: 22, borderRadius: "50%", background: "rgba(201,170,113,0.15)", border: "1px solid #C9AA71", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: "0.68rem", color: "#C9AA71", marginTop: 2 }} aria-hidden="true">✓</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* ── SIGNATURE QUOTE ── */}
        <div role="region" aria-label="Brand statement" style={{ background: "#C9AA71", padding: "76px 24px" }}>
          <div style={{ maxWidth: 860, margin: "0 auto", textAlign: "center" }}>
            <span style={{ fontSize: "4.5rem", lineHeight: 0.6, color: "#131e34", opacity: 0.28, fontFamily: "Georgia, serif", marginBottom: 20, display: "block" }} aria-hidden="true">"</span>
            <blockquote style={{ margin: 0 }}>
              <p style={{ fontFamily: "'Oswald', sans-serif", fontSize: "clamp(1.4rem, 3vw, 2rem)", fontWeight: 600, color: "#131e34", lineHeight: 1.4, marginBottom: 22 }}>Whether you are an advisor who wants better clients or an owner who wants a better exit — you need a North Star. We are it.</p>
              <footer style={{ fontSize: "0.85rem", color: "rgba(19,30,52,0.65)", fontWeight: 500, letterSpacing: "0.07em", textTransform: "uppercase" }}>— NorthStar Value Group</footer>
            </blockquote>
          </div>
        </div>

        {/* ── AUDIENCES ── */}
        <section id="audiences" aria-labelledby="audiences-heading" style={{ padding: "90px 24px", background: "#fff" }}>
          <div style={{ maxWidth: 1160, margin: "0 auto" }}>
            <div style={{ textAlign: "center", marginBottom: 60 }}>
              <span className="section-label">Who We Serve</span>
              <h2 id="audiences-heading" style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "clamp(2rem, 3.5vw, 2.8rem)", color: "#1C2B4A", marginBottom: 8 }}>Two Audiences. One Ecosystem.</h2>
              <div className="gold-divider-center" />
              <p style={{ maxWidth: 600, margin: "0 auto", color: "#555", fontSize: "1.02rem" }}>NorthStar Value Group was built to serve two distinct groups who need each other more than either one realizes.</p>
            </div>
            <div className="two-col-grid" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
              <AudienceCard
                tag="For Advisors"
                tagColor="#C9AA71"
                tagBg="rgba(201,170,113,0.12)"
                tagBorder="rgba(201,170,113,0.28)"
                bg="#1C2B4A"
                border="rgba(201,170,113,0.18)"
                title="The Trusted Advisor Collaborative"
                desc="For financial advisors, CPAs, attorneys, business coaches, and exit planning professionals who want a smarter, more dignified way to build relationships with business owner clients — without cold outreach or competing on price."
                items={["5–20+ years of professional experience","Wants a consistent pipeline of ideal business-owner clients","Believes in collaboration over competition","Committed to education-first client relationships"]}
                bulletColor="#C9AA71"
                btnLabel="Join the Collaborative →"
                btnColor="#C9AA71"
              />
              <AudienceCard
                tag="For Business Owners"
                tagColor="#B8922E"
                tagBg="rgba(184,146,46,0.12)"
                tagBorder="rgba(184,146,46,0.28)"
                bg="#1a3d2e"
                border="rgba(184,146,46,0.18)"
                title="The Business Owner Platform"
                desc="For business owners aged 40–65 with $1M–$25M in revenue who want an honest, no-pressure environment to learn what their business is really worth — and what to do about it."
                items={["5–50 employees, 5–15 years into ownership","Wants clarity on business value and exit readiness","Ready to hear the truth — not just what they want to hear","Motivated to build a business worth owning and worth buying"]}
                bulletColor="#B8922E"
                btnLabel="Join the Platform →"
                btnColor="#B8922E"
              />
            </div>
          </div>
        </section>

        {/* ── FAQ ── */}
        <section id="faq" aria-labelledby="faq-heading" style={{ padding: "90px 24px", background: "#131e34" }}>
          <div style={{ maxWidth: 860, margin: "0 auto" }}>
            <div style={{ textAlign: "center", marginBottom: 56 }}>
              <span className="section-label">Got Questions?</span>
              <h2 id="faq-heading" style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "clamp(2rem, 3.5vw, 2.8rem)", color: "#fff", marginBottom: 8 }}>Frequently Asked Questions</h2>
              <div className="gold-divider-center" />
              <p style={{ color: "rgba(255,255,255,0.62)", maxWidth: 580, margin: "0 auto", fontSize: "1.02rem" }}>Everything you need to know about NorthStar Value Group, our two platforms, and how the ecosystem works.</p>
            </div>
            <FAQAccordion items={[
              {
                q: "What is NorthStar Value Group?",
                a: "NorthStar Value Group is the parent organization uniting two powerful platforms — the Trusted Advisor Collaborative (for advisors) and the Business Owner Platform (for business owners) — under a single mission: connecting relationship-driven advisors with growth-minded business owners through education, trust, and collaboration. Just as the North Star has guided navigators for centuries, we provide unwavering direction for advisors who want to grow and for owners who want to exit — both on their own terms."
              },
              {
                q: "What is the Trusted Advisor Collaborative?",
                a: "The Trusted Advisor Collaborative is a team-based growth ecosystem for financial advisors, CPAs, attorneys, business coaches, and exit planning professionals. Rather than prospecting alone, members form local teams of 3–5 advisors with complementary disciplines, host Get A Grip Roundtables for business owners, and build trusted relationships through education — not cold outreach. It is not a CRM or lead-generation service. It is a smarter model for how advisors grow."
              },
              {
                q: "What is the Business Owner Platform?",
                a: "The Business Owner Platform is an education-first ecosystem that helps business owners build companies that run more smoothly, grow more predictably, and rely less on any one person — including the owner. Whether an owner is planning an exit, thinking about a family transition, or simply wants a better business to own, the work is the same: build real, measurable value. The platform serves business owners aged 40–65 with $1M–$25M in revenue across all industries."
              },
              {
                q: "What is a Get A Grip Roundtable?",
                a: "A Get A Grip Roundtable is an educational event hosted by Trusted Advisor Collaborative teams for business owners. There are no sales pitches — just honest education covering business valuation basics, the eight value drivers buyers care about most, the most common reasons businesses fail to sell, and what owners can do right now to build value. A team of advisors is present to answer financial, legal, operational, and strategic questions — with no agenda other than education."
              },
              {
                q: "Why do most businesses fail to sell?",
                a: "80% of businesses that go to market never successfully sell — not because they are bad businesses, but because they were never made ready. Most owners have no real visibility into what their company is worth, what buyers actually look for, or how to reduce the risk factors that suppress valuation. They are often the single point of failure in their own company, with no predictable revenue, no documented systems, and no clear story for a buyer. NorthStar Value Group addresses this through early education and preparation — years before a transaction is needed."
              },
              {
                q: "How does NorthStar Value Group help advisors grow their practice?",
                a: "Through the Trusted Advisor Collaborative, advisors stop prospecting alone and start winning together. Members form local teams with complementary professionals, use proven outreach frameworks and content libraries, and host Get A Grip Roundtables that position them as educators — not salespeople. This creates natural, permission-based follow-up conversations with qualified business owner prospects who already trust the room, replacing cold outreach with an education-first model that builds relationships before competitors even know the owner exists."
              },
              {
                q: "Who should join the Trusted Advisor Collaborative?",
                a: "The Trusted Advisor Collaborative is designed for relationship-driven professionals with 5–20+ years of experience who want a smarter, more dignified way to build a pipeline of business owner clients. Ideal members include financial advisors and wealth managers, CPAs and tax professionals, business attorneys and estate planners, business coaches, and Certified Exit Planning Advisors (CEPAs). It is not for advisors who want quick wins without relationship work, or those unwilling to collaborate and share with teammates."
              },
              {
                q: "Who is the Business Owner Platform for?",
                a: "The Business Owner Platform serves two types of business owners — both of whom need exactly the same work done. The Exit-Aware Owner knows time is finite and wants a clear roadmap to build a business a buyer actually wants. The Growth-Minded Owner is not thinking about exit yet, but wants a business that runs without them, grows more predictably, and stops depending on them for every decision. Both are welcome. Both benefit from the same education, tools, and community."
              },
            ]} />
          </div>
        </section>

        {/* ── CTA ── */}
        <section id="cta" aria-labelledby="cta-heading" style={{ padding: "100px 24px", background: "#1C2B4A", textAlign: "center", position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", left: "50%", top: "50%", transform: "translate(-50%,-50%)", fontSize: 600, color: "rgba(201,170,113,0.03)", pointerEvents: "none", lineHeight: 1, userSelect: "none", fontFamily: "serif" }} aria-hidden="true">★</div>
          <div style={{ position: "relative", zIndex: 1, maxWidth: 700, margin: "0 auto" }}>
            <span className="section-label" style={{ display: "block", textAlign: "center" }}>Your Next Step</span>
            <h2 id="cta-heading" style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: "clamp(2.2rem, 4vw, 3rem)", color: "#fff", marginBottom: 8 }}>Find Your Direction.</h2>
            <div className="gold-divider-center" />
            <p style={{ color: "rgba(255,255,255,0.7)", fontSize: "1.05rem", marginBottom: 40, lineHeight: 1.78 }}>The best outcomes for business owners happen when the right advisors are in the room — early, educated, and working together. Whether you are an advisor ready to grow your practice or an owner ready to build real value, your North Star starts here.</p>
            <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
              <a href="#" style={goldBtnStyle}>I'm an Advisor — Show Me TAC</a>
              <a href="#" style={outlineBtnStyle}>I'm a Business Owner — Show Me BOP</a>
            </div>
          </div>
        </section>
      </main>

      {/* ── FOOTER ── */}
      <footer role="contentinfo" style={{ background: "#131e34", borderTop: "1px solid rgba(201,170,113,0.14)", padding: "60px 24px 32px" }}>
        <div style={{ maxWidth: 1160, margin: "0 auto" }}>
          <div className="footer-grid" style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 48, marginBottom: 48 }}>
            <div>
              <img src={LOGO_NSV} alt="NorthStar Value Group" style={{ height: 56, width: "auto", marginBottom: 18 }} loading="lazy" />
              <p style={{ color: "rgba(255,255,255,0.5)", fontSize: "0.88rem", lineHeight: 1.72, marginBottom: 20 }}>NorthStar Value Group is the parent organization uniting the Trusted Advisor Collaborative and the Business Owner Platform — guiding advisors and empowering owners to create lasting legacies.</p>
            </div>
            {[
              ["Platforms", [["#platforms","Trusted Advisor Collaborative"],["#platforms","Business Owner Platform"],["#roundtable","Get A Grip Roundtables"]]],
              ["Company", [["#about","About Us"],["#about","Our Mission"],["#","Leadership"],["#","Partners"]]],
              ["Connect", [["#","Contact Us"],["#","Events"],["#","LinkedIn"],["#","Newsletter"]]],
            ].map(([colTitle, links]) => (
              <nav key={colTitle as string} aria-label={`Footer: ${colTitle}`}>
                <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: "0.78rem", letterSpacing: "0.15em", textTransform: "uppercase", color: "#C9AA71", marginBottom: 18 }}>{colTitle as string}</div>
                <ul style={{ listStyle: "none", margin: 0, padding: 0 }}>
                  {(links as string[][]).map(([href, label]) => (
                    <li key={label} style={{ marginBottom: 10 }}>
                      <a href={href} style={{ color: "rgba(255,255,255,0.5)", fontSize: "0.88rem", textDecoration: "none", transition: "color 0.2s" }}
                        onMouseEnter={e => (e.currentTarget.style.color = "#C9AA71")}
                        onMouseLeave={e => (e.currentTarget.style.color = "rgba(255,255,255,0.5)")}
                      >{label}</a>
                    </li>
                  ))}
                </ul>
              </nav>
            ))}
          </div>
          <div style={{ borderTop: "1px solid rgba(255,255,255,0.08)", paddingTop: 28, display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
            <p style={{ color: "rgba(255,255,255,0.32)", fontSize: "0.8rem", margin: 0 }}>© 2026 NorthStar Value Group. All rights reserved. | Guiding Advisors. Empowering Owners. Creating Legacies.</p>
            <div style={{ display: "flex", gap: 20, alignItems: "center" }}>
              <a href="#" aria-label="Trusted Advisor Collaborative"><img src={LOGO_TAC} alt="Trusted Advisor Collaborative" style={{ height: 32, width: "auto", opacity: 0.55, transition: "opacity 0.2s" }} loading="lazy" onMouseEnter={e => (e.currentTarget.style.opacity = "1")} onMouseLeave={e => (e.currentTarget.style.opacity = "0.55")} /></a>
              <a href="#" aria-label="Business Owner Platform"><img src={LOGO_BOP} alt="Business Owner Platform" style={{ height: 32, width: "auto", opacity: 0.55, transition: "opacity 0.2s" }} loading="lazy" onMouseEnter={e => (e.currentTarget.style.opacity = "1")} onMouseLeave={e => (e.currentTarget.style.opacity = "0.55")} /></a>
            </div>
          </div>
        </div>
      </footer>

      {/* ── RESPONSIVE STYLES ── */}
      <style>{`
        /* Nav show/hide */
        @media (max-width: 960px) {
          .hidden-mobile { display: none !important; }
          .show-mobile { display: flex !important; }
        }
        @media (min-width: 961px) {
          .show-mobile { display: none !important; }
        }

        /* Hero: stack on mobile */
        @media (max-width: 767px) {
          .hero-grid {
            grid-template-columns: 1fr !important;
            gap: 40px !important;
          }
          .hero-logo-panel {
            display: none !important;
          }
          .hero-stats {
            gap: 24px !important;
          }
        }

        /* Two-column sections: stack on mobile */
        @media (max-width: 767px) {
          .two-col-grid {
            grid-template-columns: 1fr !important;
            gap: 40px !important;
          }
          .values-grid {
            grid-template-columns: 1fr 1fr !important;
          }
        }

        /* Three-column: 2 cols on tablet, 1 on mobile */
        @media (max-width: 767px) {
          .three-col-grid {
            grid-template-columns: 1fr !important;
          }
          .connector-line {
            display: none !important;
          }
        }
        @media (min-width: 600px) and (max-width: 959px) {
          .three-col-grid {
            grid-template-columns: 1fr 1fr !important;
          }
          .connector-line {
            display: none !important;
          }
        }

        /* Four-column stats: 2 cols on tablet, 2 on mobile */
        @media (max-width: 767px) {
          .four-col-grid {
            grid-template-columns: 1fr 1fr !important;
            gap: 24px !important;
          }
        }

        /* Footer: single column on mobile */
        @media (max-width: 767px) {
          .footer-grid {
            grid-template-columns: 1fr !important;
            gap: 32px !important;
          }
        }

        /* Touch target sizing */
        @media (max-width: 767px) {
          a[href], button {
            min-height: 44px;
          }
          section, [role="region"] {
            padding-left: 20px !important;
            padding-right: 20px !important;
          }
        }

        /* Prevent horizontal overflow */
        * {
          box-sizing: border-box;
        }
        body {
          overflow-x: hidden;
        }
      `}</style>
    </div>
  );
}

/* ── Shared button styles ── */
const goldBtnStyle: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontFamily: "'Oswald', sans-serif",
  fontWeight: 600,
  fontSize: "0.92rem",
  letterSpacing: "0.06em",
  textTransform: "uppercase",
  padding: "14px 32px",
  borderRadius: 4,
  background: "#C9AA71",
  color: "#131e34",
  border: "2px solid #C9AA71",
  textDecoration: "none",
  transition: "background 0.2s, transform 0.2s",
  cursor: "pointer",
  minHeight: 48,
};

const outlineBtnStyle: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  fontFamily: "'Oswald', sans-serif",
  fontWeight: 600,
  fontSize: "0.92rem",
  letterSpacing: "0.06em",
  textTransform: "uppercase",
  padding: "14px 32px",
  borderRadius: 4,
  background: "transparent",
  color: "#fff",
  border: "2px solid rgba(255,255,255,0.7)",
  textDecoration: "none",
  transition: "background 0.2s, color 0.2s, transform 0.2s",
  cursor: "pointer",
  minHeight: 48,
};

/* ── Platform Card Component ── */
function PlatformCard({ logo, forLabel, forColor, bg, border, title, desc, features, arrowColor, btnLabel, btnBorder, btnHoverBg, btnHoverColor }: {
  logo: string; forLabel: string; forColor: string; bg: string; border: string;
  title: string; desc: string; features: string[]; arrowColor: string;
  btnLabel: string; btnBorder: string; btnHoverBg: string; btnHoverColor: string;
}) {
  const [hovered, setHovered] = useState(false);
  return (
    <article style={{ background: bg, border: `1px solid ${border}`, borderRadius: 10, overflow: "hidden", display: "flex", flexDirection: "column", transition: "transform 0.25s, box-shadow 0.25s", transform: hovered ? "translateY(-6px)" : "none", boxShadow: hovered ? "0 20px 50px rgba(0,0,0,0.4)" : "none" }}
      onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}>
      <div style={{ padding: "36px 36px 24px", display: "flex", justifyContent: "center" }}>
        <img src={logo} alt={forLabel} style={{ height: 80, width: "auto", objectFit: "contain" }} loading="lazy" />
      </div>
      <div style={{ padding: "0 36px 36px", flex: 1, display: "flex", flexDirection: "column" }}>
        <span style={{ fontFamily: "'Oswald', sans-serif", fontSize: "0.73rem", letterSpacing: "0.18em", textTransform: "uppercase", color: forColor, marginBottom: 10, display: "block" }}>{forLabel}</span>
        <h3 style={{ fontFamily: "'Oswald', sans-serif", fontSize: "1.5rem", fontWeight: 700, color: "#fff", marginBottom: 16, lineHeight: 1.22 }}>{title}</h3>
        <p style={{ color: "rgba(255,255,255,0.72)", fontSize: "0.96rem", lineHeight: 1.76, marginBottom: 24, flex: 1 }}>{desc}</p>
        <ul style={{ listStyle: "none", margin: "0 0 30px", padding: 0 }}>
          {features.map((f, i) => (
            <li key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, fontSize: "0.91rem", color: "rgba(255,255,255,0.78)", marginBottom: 10, lineHeight: 1.52 }}>
              <span style={{ color: arrowColor, flexShrink: 0 }} aria-hidden="true">→</span>{f}
            </li>
          ))}
        </ul>
        <a href="#" style={{ display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "0.88rem", letterSpacing: "0.08em", textTransform: "uppercase", padding: "13px 24px", borderRadius: 4, border: `2px solid ${btnBorder}`, color: btnBorder, textAlign: "center", textDecoration: "none", transition: "background 0.2s, color 0.2s", minHeight: 48 }}
          onMouseEnter={e => { (e.currentTarget as HTMLAnchorElement).style.background = btnHoverBg; (e.currentTarget as HTMLAnchorElement).style.color = btnHoverColor; }}
          onMouseLeave={e => { (e.currentTarget as HTMLAnchorElement).style.background = "transparent"; (e.currentTarget as HTMLAnchorElement).style.color = btnBorder; }}
        >{btnLabel}</a>
      </div>
    </article>
  );
}

/* ── FAQ Accordion Component ── */
function FAQAccordion({ items }: { items: { q: string; a: string }[] }) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  return (
    <dl style={{ margin: 0, padding: 0 }}>
      {items.map((item, i) => {
        const isOpen = openIndex === i;
        return (
          <div key={i} style={{
            borderBottom: "1px solid rgba(201,170,113,0.18)",
            borderTop: i === 0 ? "1px solid rgba(201,170,113,0.18)" : "none",
          }}>
            <dt>
              <button
                onClick={() => setOpenIndex(isOpen ? null : i)}
                aria-expanded={isOpen}
                aria-controls={`faq-answer-${i}`}
                id={`faq-question-${i}`}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: 16,
                  background: "none",
                  border: "none",
                  padding: "22px 0",
                  cursor: "pointer",
                  textAlign: "left",
                  minHeight: 44,
                }}
              >
                <span style={{
                  fontFamily: "'Oswald', sans-serif",
                  fontWeight: 600,
                  fontSize: "1.05rem",
                  color: isOpen ? "#C9AA71" : "#fff",
                  lineHeight: 1.35,
                  transition: "color 0.2s",
                  flex: 1,
                }}>{item.q}</span>
                <span style={{
                  width: 28,
                  height: 28,
                  borderRadius: "50%",
                  border: `2px solid ${isOpen ? "#C9AA71" : "rgba(201,170,113,0.4)"}`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                  color: isOpen ? "#C9AA71" : "rgba(201,170,113,0.7)",
                  fontSize: "1.1rem",
                  lineHeight: 1,
                  transition: "transform 0.25s, border-color 0.2s, color 0.2s",
                  transform: isOpen ? "rotate(45deg)" : "none",
                }} aria-hidden="true">+</span>
              </button>
            </dt>
            <dd
              id={`faq-answer-${i}`}
              role="region"
              aria-labelledby={`faq-question-${i}`}
              style={{
                margin: 0,
                overflow: "hidden",
                maxHeight: isOpen ? 400 : 0,
                transition: "max-height 0.35s ease, opacity 0.25s ease",
                opacity: isOpen ? 1 : 0,
              }}
            >
              <p style={{
                color: "rgba(255,255,255,0.72)",
                fontSize: "0.97rem",
                lineHeight: 1.78,
                paddingBottom: 24,
                margin: 0,
              }}>{item.a}</p>
            </dd>
          </div>
        );
      })}
    </dl>
  );
}

/* ── Audience Card Component ── */
function AudienceCard({ tag, tagColor, tagBg, tagBorder, bg, border, title, desc, items, bulletColor, btnLabel, btnColor }: {
  tag: string; tagColor: string; tagBg: string; tagBorder: string; bg: string; border: string;
  title: string; desc: string; items: string[]; bulletColor: string; btnLabel: string; btnColor: string;
}) {
  return (
    <article style={{ background: bg, border: `1px solid ${border}`, borderRadius: 10, padding: "44px 40px" }}>
      <span style={{ fontFamily: "'Oswald', sans-serif", fontSize: "0.7rem", letterSpacing: "0.2em", textTransform: "uppercase", padding: "5px 14px", borderRadius: 20, display: "inline-block", marginBottom: 20, fontWeight: 600, background: tagBg, color: tagColor, border: `1px solid ${tagBorder}` }}>{tag}</span>
      <h3 style={{ fontFamily: "'Oswald', sans-serif", fontSize: "1.45rem", fontWeight: 700, color: "#fff", marginBottom: 14 }}>{title}</h3>
      <p style={{ color: "rgba(255,255,255,0.7)", fontSize: "0.96rem", lineHeight: 1.76, marginBottom: 26 }}>{desc}</p>
      <ul style={{ listStyle: "none", margin: "0 0 30px", padding: 0 }}>
        {items.map((item, i) => (
          <li key={i} style={{ color: "rgba(255,255,255,0.78)", fontSize: "0.91rem", padding: "8px 0", borderBottom: "1px solid rgba(255,255,255,0.07)", display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ color: bulletColor, fontSize: "0.6rem" }} aria-hidden="true">✦</span>{item}
          </li>
        ))}
      </ul>
      <a href="#" style={{ display: "inline-flex", alignItems: "center", fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: "0.9rem", letterSpacing: "0.06em", textTransform: "uppercase", padding: "13px 28px", borderRadius: 4, border: `2px solid ${btnColor}`, color: btnColor, textDecoration: "none", transition: "background 0.2s, color 0.2s", minHeight: 48 }}
        onMouseEnter={e => { (e.currentTarget as HTMLAnchorElement).style.background = btnColor; (e.currentTarget as HTMLAnchorElement).style.color = "#131e34"; }}
        onMouseLeave={e => { (e.currentTarget as HTMLAnchorElement).style.background = "transparent"; (e.currentTarget as HTMLAnchorElement).style.color = btnColor; }}
      >{btnLabel}</a>
    </article>
  );
}
